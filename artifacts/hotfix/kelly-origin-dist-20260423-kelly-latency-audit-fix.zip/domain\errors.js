export class AppError extends Error {
    statusCode;
    code;
    retryable;
    staleAvailable;
    lastSuccessAt;
    constructor(statusCode, code, message, options) {
        super(message);
        this.name = "AppError";
        this.statusCode = statusCode;
        this.code = code;
        this.retryable = options?.retryable ?? false;
        this.staleAvailable = options?.staleAvailable ?? false;
        this.lastSuccessAt = options?.lastSuccessAt ?? null;
    }
    toPayload() {
        return {
            code: this.code,
            message: this.message,
            retryable: this.retryable,
            staleAvailable: this.staleAvailable,
            lastSuccessAt: this.lastSuccessAt,
        };
    }
}
export const isAppError = (error) => error instanceof AppError;
