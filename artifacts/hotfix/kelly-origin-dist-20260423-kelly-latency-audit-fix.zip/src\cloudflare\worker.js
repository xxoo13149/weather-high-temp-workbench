import { DEFAULT_LOCATION, LOCATION_DIRECTORY, LOCATION_REGISTRY } from "../config.js";
import { AppError, isAppError } from "../domain/errors.js";
import { MeteoblueWeatherService } from "../providers/meteoblue/service.js";
import { CloudflareFavoritesStore, InMemoryFavoritesStore } from "./favorites-store.js";
let runtimeBuildId = null;
let runtimeStartedAt = null;
let servicePromise = null;
const KELLY_PROXY_FAILURE_THRESHOLD = 3;
const KELLY_PROXY_FAILURE_WINDOW_MS = 60_000;
const KELLY_PROXY_OPEN_DURATION_MS = 5 * 60_000;
const KELLY_PROXY_GET_TIMEOUT_MS = 12_000;
const KELLY_PROXY_STREAM_TIMEOUT_MS = 6_000;
const kellyProxyCircuit = {
    failureTimestamps: [],
    consecutiveFailures: 0,
    openUntil: null,
    halfOpenProbeInFlight: false,
    lastOriginSuccessAt: null,
    lastOriginFailureAt: null,
    lastOriginFailureCode: null,
    localFallbackActive: false,
};
const ensureRuntimeMetadata = () => {
    const rawBuildId = typeof process !== "undefined" && process.env && typeof process.env.BUILD_ID === "string"
        ? process.env.BUILD_ID.trim()
        : "";
    if (!runtimeBuildId) {
        const generatedBuildId = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
            ? `worker-${crypto.randomUUID()}`
            : `worker-${Math.random().toString(36).slice(2, 10)}`;
        runtimeBuildId = rawBuildId || generatedBuildId;
    }
    if (!runtimeStartedAt) {
        runtimeStartedAt = new Date().toISOString();
    }
    return {
        buildId: runtimeBuildId,
        startedAt: runtimeStartedAt,
    };
};
const getService = async (env) => {
    if (!servicePromise) {
        const favoritesStore = env.FAVORITES_KV
            ? new CloudflareFavoritesStore(env.FAVORITES_KV)
            : new InMemoryFavoritesStore();
        servicePromise = Promise.resolve(new MeteoblueWeatherService({ favoritesStore }));
    }
    return await servicePromise;
};
const buildLocationDirectory = () => LOCATION_DIRECTORY.map((location) => ({
    id: location.id,
    code: location.code,
    displayName: location.displayName,
    displayNameZh: location.displayNameZh,
    shortLabel: location.shortLabel,
    cityName: location.cityName,
    countryName: location.countryName,
    timezone: location.timezone,
    timezoneGroup: location.timezoneGroup,
    displayUnit: location.fallbackDisplayUnit,
    enabled: location.enabled,
    sortOrder: location.sortOrder,
    fallbackDisplayUnit: location.fallbackDisplayUnit,
    weekPageUrl: location.weekPageUrl,
    multimodelPageUrl: location.multimodelPageUrl,
}));
const parseMode = (raw) => {
    if (raw === null || raw === "" || raw === "1h") {
        return "1h";
    }
    if (raw === "3h") {
        return "3h";
    }
    throw new AppError(400, "BAD_REQUEST", "Query parameter 'mode' must be either '1h' or '3h'.");
};
const parseLimit = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    const value = Number.parseInt(raw, 10);
    if (!Number.isFinite(value) || value <= 0) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'limit' must be a positive integer.");
    }
    return value;
};
const parseAllowStale = (raw) => raw === "true" || raw === "1";
const parseTimestamp = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    const parsed = new Date(raw);
    if (Number.isNaN(parsed.getTime())) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'timestamp' must be a valid ISO timestamp.");
    }
    return raw;
};
const parseBucketSize = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    const value = Number.parseFloat(raw);
    if (!Number.isFinite(value) || value <= 0) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'bucketSize' must be a positive number.");
    }
    return value;
};
const parseFloatNumber = (raw, message) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    const value = Number.parseFloat(raw);
    if (!Number.isFinite(value)) {
        throw new AppError(400, "BAD_REQUEST", message);
    }
    return value;
};
const parseActualTemperatureC = (raw) => parseFloatNumber(raw, "Query parameter 'actualTemperatureC' must be a finite number.");
const parseKellyTargetDate = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'targetDate' must use YYYY-MM-DD format.");
    }
    return raw;
};
const parseBankroll = (raw) => {
    const value = parseFloatNumber(raw, "Query parameter 'bankroll' must be a positive number.");
    if (value === undefined) {
        return undefined;
    }
    if (value <= 0) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'bankroll' must be a positive number.");
    }
    return value;
};
const parseKellyRiskMode = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    if (raw === "conservative" || raw === "balanced" || raw === "aggressive") {
        return raw;
    }
    throw new AppError(400, "BAD_REQUEST", "Query parameter 'riskMode' must be conservative, balanced, or aggressive.");
};
const parseKellyMinEdge = (raw) => {
    const value = parseFloatNumber(raw, "Query parameter 'minEdge' must be between 0 and 1.");
    if (value === undefined) {
        return undefined;
    }
    if (value < 0 || value > 1) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'minEdge' must be between 0 and 1.");
    }
    return value;
};
const parseForceRefresh = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    if (raw === "true" || raw === "1") {
        return true;
    }
    if (raw === "false" || raw === "0") {
        return false;
    }
    throw new AppError(400, "BAD_REQUEST", "Query parameter 'forceRefresh' must be boolean.");
};
const parseQueryLocationId = (raw) => {
    if (raw === null || raw === "") {
        return DEFAULT_LOCATION;
    }
    const locationId = raw.trim();
    if (!(locationId in LOCATION_REGISTRY)) {
        throw new AppError(400, "BAD_REQUEST", `Query parameter 'locationId' is not supported: '${raw}'.`);
    }
    return locationId;
};
const parseFavoriteBody = (raw) => {
    if (typeof raw !== "object" || raw === null || !("favorite" in raw)) {
        throw new AppError(400, "BAD_REQUEST", "Request body must include a boolean 'favorite' field.");
    }
    const value = raw.favorite;
    if (typeof value !== "boolean") {
        throw new AppError(400, "BAD_REQUEST", "Request body field 'favorite' must be boolean.");
    }
    return value;
};
const parseKellyOptions = (url) => ({
    targetDate: parseKellyTargetDate(url.searchParams.get("targetDate")),
    bankroll: parseBankroll(url.searchParams.get("bankroll")),
    riskMode: parseKellyRiskMode(url.searchParams.get("riskMode")),
    minEdge: parseKellyMinEdge(url.searchParams.get("minEdge")),
    actualTemperatureC: parseActualTemperatureC(url.searchParams.get("actualTemperatureC")),
    selectedHourTimestamp: parseTimestamp(url.searchParams.get("selectedHour")),
    forceRefresh: parseForceRefresh(url.searchParams.get("forceRefresh")),
});
const DEFAULT_CACHE_CONTROL = "no-store, max-age=0";
const EDGE_CACHE_TTL_SECONDS = {
    hourly: 45,
    report: 45,
    dashboard: 30,
    multimodelStatus: 45,
    multimodelInsight: 90,
    multimodelDistribution: 90,
};
const buildEdgeCacheControl = (ttlSeconds) => `public, max-age=0, s-maxage=${ttlSeconds}, stale-while-revalidate=${ttlSeconds}`;
const jsonResponse = (payload, status = 200, headers) => new Response(JSON.stringify(payload), {
    status,
    headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": DEFAULT_CACHE_CONTROL,
        ...(headers ?? {}),
    },
});
const withEdgeJsonCache = async (request, ctx, ttlSeconds, loader, options) => {
    const edgeCache = typeof caches === "undefined" ? null : (caches.default ?? null);
    if (!edgeCache) {
        return jsonResponse(await loader());
    }
    const cacheKey = new Request(request.url, {
        method: "GET",
    });
    const cachedResponse = await edgeCache.match(cacheKey);
    if (cachedResponse) {
        return cachedResponse;
    }
    const cacheControl = buildEdgeCacheControl(ttlSeconds);
    const payload = await loader();
    if (options?.shouldCache && !options.shouldCache(payload)) {
        return jsonResponse(payload);
    }
    const response = jsonResponse(payload, 200, {
        "cache-control": cacheControl,
        "cdn-cache-control": cacheControl,
    });
    ctx.waitUntil(edgeCache.put(cacheKey, response.clone()));
    return response;
};
const hasFreshFreshness = (payload) => typeof payload !== "object" ||
    payload === null ||
    !("freshness" in payload) ||
    payload.freshness === "fresh";
const hasFreshDashboardSync = (payload) => typeof payload === "object" &&
    payload !== null &&
    "sync" in payload &&
    typeof payload.sync?.freshness === "string" &&
    payload.sync.freshness === "fresh";
const resolvePayloadFreshness = (payload, staleFallback) => {
    if (typeof payload === "object" && payload !== null && typeof payload.freshness === "string") {
        return payload.freshness;
    }
    return staleFallback ? "fallback_error" : "fresh";
};
const handleError = (error) => {
    if (isAppError(error)) {
        return jsonResponse(error.toPayload(), error.statusCode);
    }
    const fallback = new AppError(500, "INTERNAL_SERVER_ERROR", "Unexpected server error.");
    return jsonResponse(fallback.toPayload(), 500);
};
const sendSocketMessage = (socket, message) => {
    try {
        socket.send(JSON.stringify(message));
    }
    catch {
        socket.close();
    }
};
const createWebSocketUpgradeResponse = (client) => {
    try {
        return new Response(null, {
            status: 101,
            ...{ webSocket: client },
        });
    }
    catch {
        const response = new Response(null, {
            status: 200,
            headers: {
                "x-worker-websocket-upgrade": "101",
            },
        });
        Object.defineProperty(response, "webSocket", {
            configurable: true,
            value: client,
        });
        return response;
    }
};
const resolveKellyServerBaseUrl = (env) => {
    const raw = env.KELLY_SERVER_BASE_URL?.trim();
    if (!raw) {
        return null;
    }
    try {
        const parsed = new URL(raw);
        return parsed.toString().replace(/\/+$/, "");
    }
    catch {
        throw new AppError(500, "INVALID_KELLY_SERVER_BASE_URL", "Worker env 'KELLY_SERVER_BASE_URL' must be a valid absolute URL.");
    }
};
const buildKellyProxyRequest = (request, env) => {
    const baseUrl = resolveKellyServerBaseUrl(env);
    if (!baseUrl) {
        return null;
    }
    const incomingUrl = new URL(request.url);
    const upstreamUrl = `${baseUrl}${incomingUrl.pathname}${incomingUrl.search}`;
    const headers = new Headers(request.headers);
    headers.set("x-weather-kelly-proxy", "cloudflare-worker");
    return new Request(upstreamUrl, {
        method: request.method,
        headers,
    });
};
const pruneKellyProxyFailures = (now = Date.now()) => {
    kellyProxyCircuit.failureTimestamps = kellyProxyCircuit.failureTimestamps.filter((timestamp) => now - timestamp <= KELLY_PROXY_FAILURE_WINDOW_MS);
};
const resolveKellyProxyCircuitState = () => {
    if (kellyProxyCircuit.openUntil !== null) {
        return Date.now() < kellyProxyCircuit.openUntil ? "open" : "half-open";
    }
    return kellyProxyCircuit.halfOpenProbeInFlight ? "half-open" : "closed";
};
const recordKellyOriginSuccess = () => {
    kellyProxyCircuit.failureTimestamps = [];
    kellyProxyCircuit.consecutiveFailures = 0;
    kellyProxyCircuit.openUntil = null;
    kellyProxyCircuit.halfOpenProbeInFlight = false;
    kellyProxyCircuit.lastOriginSuccessAt = new Date().toISOString();
    kellyProxyCircuit.localFallbackActive = false;
};
const recordKellyOriginFailure = (reasonCode) => {
    const now = Date.now();
    pruneKellyProxyFailures(now);
    kellyProxyCircuit.failureTimestamps.push(now);
    kellyProxyCircuit.consecutiveFailures += 1;
    kellyProxyCircuit.lastOriginFailureAt = new Date(now).toISOString();
    kellyProxyCircuit.lastOriginFailureCode = reasonCode;
    kellyProxyCircuit.localFallbackActive = true;
    kellyProxyCircuit.halfOpenProbeInFlight = false;
    if (kellyProxyCircuit.failureTimestamps.length >= KELLY_PROXY_FAILURE_THRESHOLD) {
        kellyProxyCircuit.openUntil = now + KELLY_PROXY_OPEN_DURATION_MS;
    }
};
const shouldBypassKellyOrigin = () => {
    if (kellyProxyCircuit.openUntil === null) {
        return false;
    }
    if (Date.now() < kellyProxyCircuit.openUntil) {
        return true;
    }
    if (kellyProxyCircuit.halfOpenProbeInFlight) {
        return true;
    }
    kellyProxyCircuit.halfOpenProbeInFlight = true;
    return false;
};
const isKellyOriginJsonResponse = (response) => (response.headers.get("content-type") ?? "").toLowerCase().includes("application/json");
const fetchKellyOrigin = async (request, env, timeoutMs) => {
    const proxyRequest = buildKellyProxyRequest(request, env);
    if (!proxyRequest) {
        return { kind: "unconfigured" };
    }
    if (shouldBypassKellyOrigin()) {
        kellyProxyCircuit.localFallbackActive = true;
        return {
            kind: "fallback",
            reasonCode: "origin_circuit_open",
            circuitState: resolveKellyProxyCircuitState(),
        };
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
        controller.abort();
    }, timeoutMs);
    try {
        const response = await fetch(new Request(proxyRequest, {
            signal: controller.signal,
        }));
        if (response.ok) {
            recordKellyOriginSuccess();
            return {
                kind: "passthrough",
                response,
            };
        }
        if (response.status >= 400 && response.status < 500 && isKellyOriginJsonResponse(response)) {
            recordKellyOriginSuccess();
            return {
                kind: "passthrough",
                response,
            };
        }
        const reasonCode = `origin_status_${response.status}`;
        recordKellyOriginFailure(reasonCode);
        return {
            kind: "fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(),
        };
    }
    catch (error) {
        const reasonCode = error instanceof Error && error.name === "AbortError" ? "origin_timeout" : "origin_fetch_failed";
        recordKellyOriginFailure(reasonCode);
        return {
            kind: "fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(),
        };
    }
    finally {
        clearTimeout(timeoutId);
    }
};
const buildKellyProxyHealth = (env) => ({
    configured: Boolean(resolveKellyServerBaseUrl(env)),
    originBaseUrl: resolveKellyServerBaseUrl(env),
    circuitState: resolveKellyProxyCircuitState(),
    consecutiveFailures: kellyProxyCircuit.consecutiveFailures,
    openUntil: kellyProxyCircuit.openUntil === null ? null : new Date(kellyProxyCircuit.openUntil).toISOString(),
    lastOriginSuccessAt: kellyProxyCircuit.lastOriginSuccessAt,
    lastOriginFailureAt: kellyProxyCircuit.lastOriginFailureAt,
    lastOriginFailureCode: kellyProxyCircuit.lastOriginFailureCode,
    localFallbackActive: kellyProxyCircuit.localFallbackActive,
});
const handleKellyStream = async (request, env, ctx) => {
    if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
        return new Response("Expected Upgrade: websocket", { status: 426 });
    }
    const originAttempt = await fetchKellyOrigin(request, env, KELLY_PROXY_STREAM_TIMEOUT_MS);
    if (originAttempt.kind === "passthrough") {
        return originAttempt.response;
    }
    const url = new URL(request.url);
    const locationId = parseQueryLocationId(url.searchParams.get("locationId"));
    const pair = new (globalThis.WebSocketPair)();
    const client = pair[0];
    const server = pair[1];
    server.accept();
    const service = await getService(env);
    ctx.waitUntil((async () => {
        if (!service.createKellyStream) {
            sendSocketMessage(server, {
                type: "status",
                generatedAt: new Date().toISOString(),
                state: "unavailable",
                reasonCode: "upstream_error",
                message: "Kelly real-time stream is not configured.",
            });
            server.close(1011, "kelly-stream-unavailable");
            return;
        }
        try {
            const stream = await service.createKellyStream(locationId, parseKellyOptions(url), (message) => sendSocketMessage(server, originAttempt.kind === "fallback"
                ? {
                    ...message,
                    originMode: "local-fallback",
                    circuitState: originAttempt.circuitState,
                }
                : message));
            const closeStream = async () => {
                try {
                    await stream.close();
                }
                catch {
                    // Ignore cleanup failures.
                }
            };
            server.addEventListener("close", () => {
                ctx.waitUntil(closeStream());
            });
            server.addEventListener("error", () => {
                ctx.waitUntil(closeStream());
            });
        }
        catch (error) {
            sendSocketMessage(server, {
                type: "status",
                generatedAt: new Date().toISOString(),
                state: "degraded",
                reasonCode: "upstream_error",
                message: error instanceof Error ? error.message : "Kelly realtime stream initialization failed.",
            });
            server.close(1011, "kelly-stream-error");
        }
    })());
    return createWebSocketUpgradeResponse(client);
};
const handleApiRequest = async (request, env, ctx) => {
    const url = new URL(request.url);
    const runtimeMetadata = ensureRuntimeMetadata();
    if (request.method === "GET" && url.pathname === "/healthz") {
        return jsonResponse({
            ok: true,
            service: "weather-worker",
            buildId: runtimeMetadata.buildId,
            startedAt: runtimeMetadata.startedAt,
            kellyProxy: buildKellyProxyHealth(env),
        });
    }
    if (request.method === "GET" && url.pathname === "/api/weather/kelly") {
        const originAttempt = await fetchKellyOrigin(request, env, KELLY_PROXY_GET_TIMEOUT_MS);
        if (originAttempt.kind === "passthrough") {
            return originAttempt.response;
        }
        const service = await getService(env);
        const locationId = parseQueryLocationId(url.searchParams.get("locationId"));
        if (!service.getKellyWorkbench) {
            throw new AppError(503, "KELLY_UNAVAILABLE", "Kelly workbench is not configured.", {
                retryable: false,
            });
        }
        return jsonResponse(await service.getKellyWorkbench(locationId, parseKellyOptions(url)));
    }
    const service = await getService(env);
    const locationId = parseQueryLocationId(url.searchParams.get("locationId"));
    switch (`${request.method} ${url.pathname}`) {
        case "GET /api/weather/hourly":
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.hourly, async () => await service.getHourly(locationId, parseMode(url.searchParams.get("mode")), parseLimit(url.searchParams.get("limit"))), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/weather/report":
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.report, async () => await service.getWeatherReport(locationId), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/weather/dashboard": {
            const mode = parseMode(url.searchParams.get("mode"));
            const limit = parseLimit(url.searchParams.get("limit"));
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.dashboard, async () => {
                const [hourly, multimodel, report] = await Promise.all([
                    service.getHourly(locationId, mode, limit),
                    service.getMultiModelStatus(locationId),
                    service.getWeatherReport(locationId),
                ]);
                const syncState = hourly.freshness === "fallback_error" || report.freshness === "fallback_error"
                    ? "fallback_error"
                    : "fresh";
                return {
                    generatedAt: new Date().toISOString(),
                    displayUnit: LOCATION_REGISTRY[locationId].fallbackDisplayUnit,
                    sync: {
                        state: syncState,
                        freshness: syncState,
                        label: syncState === "fallback_error"
                            ? "fallback_error"
                            : "synced",
                        updatedAt: hourly.fetchedAt,
                    },
                    locationDirectory: buildLocationDirectory(),
                    hourly,
                    report,
                    multimodel: {
                        ...multimodel,
                        imageProxyUrl: `/api/weather/multimodel/image?allowStale=true&locationId=${encodeURIComponent(locationId)}`,
                        displayUpdatedAt: multimodel.imageFetchedAt ?? multimodel.lastSuccessAt,
                        sourceType: "official-relayed-image",
                        parity: "exact-image-relay",
                        statusLabel: multimodel.imageStatus === "unavailable" && !multimodel.imageUrlFound
                            ? "unavailable"
                            : multimodel.freshness === "fallback_error"
                                ? "fallback_error"
                                : multimodel.freshness === "revalidating"
                                    ? "revalidating"
                                    : "ready",
                    },
                };
            }, {
                shouldCache: hasFreshDashboardSync,
            });
        }
        case "GET /api/weather/multimodel/image": {
            const image = await service.getMultiModelImage(locationId, parseAllowStale(url.searchParams.get("allowStale")));
            const headers = new Headers(image.headers);
            headers.set("content-type", image.contentType);
            return new Response(new Uint8Array(image.body), {
                status: 200,
                headers,
            });
        }
        case "GET /api/weather/multimodel/status":
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.multimodelStatus, async () => await service.getMultiModelStatus(locationId), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/weather/multimodel/distribution":
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.multimodelDistribution, async () => await service.getMultiModelDistribution(locationId, parseTimestamp(url.searchParams.get("timestamp")), parseBucketSize(url.searchParams.get("bucketSize"))), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/weather/multimodel/insights":
            if (!service.getMultiModelInsight) {
                throw new AppError(503, "MULTIMODEL_INSIGHT_UNAVAILABLE", "Multimodel insights endpoint is not configured.", {
                    retryable: false,
                });
            }
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.multimodelInsight, async () => await service.getMultiModelInsight(locationId, parseTimestamp(url.searchParams.get("timestamp")), parseActualTemperatureC(url.searchParams.get("actualTemperatureC"))), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/user/favorites":
            if (!service.getUserFavorites) {
                throw new AppError(503, "FAVORITES_UNAVAILABLE", "Favorites endpoint is not configured.", {
                    retryable: false,
                });
            }
            return jsonResponse(await service.getUserFavorites());
        default:
            break;
    }
    if (request.method === "PUT" && url.pathname.startsWith("/api/user/favorites/")) {
        if (!service.setUserFavorite) {
            throw new AppError(503, "FAVORITES_UNAVAILABLE", "Favorites endpoint is not configured.", {
                retryable: false,
            });
        }
        const locationPath = decodeURIComponent(url.pathname.slice("/api/user/favorites/".length));
        if (!locationPath) {
            throw new AppError(400, "BAD_REQUEST", "Path parameter 'locationId' must be a non-empty string.");
        }
        const favorite = parseFavoriteBody(await request.json());
        return jsonResponse(await service.setUserFavorite(locationPath, favorite));
    }
    throw new AppError(404, "NOT_FOUND", "Route not found.");
};
const isApiRequest = (pathname) => pathname === "/healthz" || pathname.startsWith("/api/");
export default {
    async fetch(request, env, ctx) {
        const url = new URL(request.url);
        ensureRuntimeMetadata();
        try {
            if (url.pathname === "/api/weather/kelly/stream") {
                return await handleKellyStream(request, env, ctx);
            }
            if (isApiRequest(url.pathname)) {
                return await handleApiRequest(request, env, ctx);
            }
            return await env.ASSETS.fetch(request);
        }
        catch (error) {
            return handleError(error);
        }
    },
};
