import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";
const createEnv = (overrides = {}) => ({
    ASSETS: {
        fetch: vi.fn(async () => new Response("asset", { status: 200 })),
    },
    ...overrides,
});
const createContext = () => ({
    waitUntil: vi.fn(),
});
const createEdgeCache = () => ({
    match: vi.fn(async () => null),
    put: vi.fn(async () => undefined),
});
const createTrackedContext = () => {
    const pending = [];
    return {
        waitUntil: vi.fn((promise) => {
            pending.push(Promise.resolve(promise));
        }),
        flush: async () => {
            while (pending.length > 0) {
                const batch = pending.splice(0, pending.length);
                await Promise.allSettled(batch);
            }
        },
    };
};
class MockCloudflareWebSocket extends EventTarget {
    accepted = false;
    closed = false;
    sent = [];
    accept() {
        this.accepted = true;
    }
    send(payload) {
        this.sent.push(JSON.parse(payload));
    }
    close() {
        if (this.closed) {
            return;
        }
        this.closed = true;
        this.dispatchEvent(new Event("close"));
    }
}
class MockWebSocketPair {
    static lastPair = null;
    0;
    1;
    constructor() {
        this[0] = new MockCloudflareWebSocket();
        this[1] = new MockCloudflareWebSocket();
        MockWebSocketPair.lastPair = this;
    }
}
const loadWorker = async () => {
    vi.resetModules();
    const module = (await import("../src/cloudflare/worker.js"));
    return module.default;
};
beforeEach(() => {
    vi.restoreAllMocks();
});
afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
    vi.doUnmock("../src/providers/meteoblue/service.js");
});
describe("cloudflare worker kelly routing", () => {
    test("reports worker runtime metadata on /healthz", async () => {
        const worker = await loadWorker();
        const env = createEnv();
        const response = await worker.fetch(new Request("https://lukaluka.fun/healthz"), env, createContext());
        expect(response.status).toBe(200);
        await expect(response.json()).resolves.toMatchObject({
            ok: true,
            service: "weather-worker",
            buildId: expect.any(String),
            startedAt: expect.any(String),
        });
    }, 15_000);
    test("serves legacy Kelly GET requests through the worker-local service", async () => {
        const env = createEnv();
        const fetchMock = vi.spyOn(globalThis, "fetch");
        const getKellyWorkbench = vi.fn(async (locationId) => ({
            location: {
                id: locationId,
                name: "Miami International Airport",
                timezone: "America/New_York",
            },
            displayUnit: "F",
            generatedAt: "2026-04-10T00:00:00.000Z",
            targetDate: "2026-04-10",
            availableTargetDates: ["2026-04-10"],
            bankroll: 1000,
            riskMode: "balanced",
            riskMultiplier: 0.5,
            minEdge: 0.02,
            summaryMetrics: [],
            opportunities: [],
            markets: [],
            inactiveMarkets: [],
            sourceLinks: {
                polymarketSearchUrl: "https://polymarket.com",
                marketUrls: [],
            },
        }));
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                getKellyWorkbench = getKellyWorkbench;
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/kelly?locationId=miami_mia"), env, createContext());
        expect(response.status).toBe(200);
        await expect(response.json()).resolves.toMatchObject({
            location: {
                id: "miami_mia",
            },
            displayUnit: "F",
        });
        expect(getKellyWorkbench).toHaveBeenCalledWith("miami_mia", expect.any(Object));
        expect(fetchMock).not.toHaveBeenCalled();
    });
    test("serves newly added Kelly GET requests through the worker-local service", async () => {
        const env = createEnv();
        const fetchMock = vi.spyOn(globalThis, "fetch");
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                async getKellyWorkbench(locationId) {
                    return {
                        location: {
                            id: locationId,
                            name: "Amsterdam Airport Schiphol",
                            timezone: "Europe/Amsterdam",
                        },
                        displayUnit: "C",
                        generatedAt: "2026-04-10T00:00:00.000Z",
                        targetDate: "2026-04-10",
                        availableTargetDates: ["2026-04-10"],
                        bankroll: 1000,
                        riskMode: "balanced",
                        riskMultiplier: 0.5,
                        minEdge: 0.02,
                        summaryMetrics: [],
                        opportunities: [],
                        markets: [],
                        inactiveMarkets: [],
                        sourceLinks: {
                            polymarketSearchUrl: "https://polymarket.com",
                            marketUrls: [],
                        },
                    };
                }
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/kelly?locationId=amsterdam_ams"), env, createContext());
        expect(response.status).toBe(200);
        await expect(response.json()).resolves.toMatchObject({
            location: {
                id: "amsterdam_ams",
            },
            displayUnit: "C",
        });
        expect(fetchMock).not.toHaveBeenCalled();
    });
    test("streams Kelly locations through the worker-local realtime service", async () => {
        const env = createEnv();
        const context = createTrackedContext();
        const fetchMock = vi.spyOn(globalThis, "fetch");
        const createKellyStream = vi.fn(async (locationId, _options, onMessage) => {
            onMessage({
                type: "status",
                generatedAt: "2026-04-11T01:02:03.000Z",
                state: "connected",
                reasonCode: "ws_connected",
                message: "stream connected",
            });
            onMessage({
                type: "markets",
                generatedAt: "2026-04-11T01:02:04.000Z",
                markets: [{ marketId: `${locationId}-market-1` }],
                frames: [],
            });
            return {
                close: vi.fn(),
            };
        });
        MockWebSocketPair.lastPair = null;
        vi.stubGlobal("WebSocketPair", MockWebSocketPair);
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                createKellyStream = createKellyStream;
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/kelly/stream?locationId=amsterdam_ams", {
            headers: {
                Upgrade: "websocket",
            },
        }), env, context);
        expect(fetchMock).not.toHaveBeenCalled();
        expect(response.headers.get("x-worker-websocket-upgrade")).toBe("101");
        expect(createKellyStream).toHaveBeenCalledWith("amsterdam_ams", expect.any(Object), expect.any(Function));
        await context.flush();
        const server = MockWebSocketPair.lastPair?.[1];
        expect(server).toBeTruthy();
        if (!server) {
            throw new Error("Expected worker stream server socket to exist.");
        }
        expect(server.accepted).toBe(true);
        expect(server.sent).toEqual(expect.arrayContaining([
            expect.objectContaining({
                type: "status",
                state: "connected",
                reasonCode: "ws_connected",
            }),
            expect.objectContaining({
                type: "markets",
                generatedAt: "2026-04-11T01:02:04.000Z",
            }),
        ]));
        server.close();
        await context.flush();
    });
    test("proxies Kelly GET requests when Kelly server is configured", async () => {
        const proxyUrl = "https://kelly-proxy.example";
        const env = createEnv({ KELLY_SERVER_BASE_URL: proxyUrl });
        const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ proxied: true }), {
            status: 200,
            headers: { "content-type": "application/json" },
        }));
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/kelly?locationId=miami_mia"), env, createContext());
        expect(fetchMock).toHaveBeenCalledTimes(1);
        const [requested] = fetchMock.mock.calls[0];
        expect(requested).toBeInstanceOf(Request);
        expect(requested.url).toBe(`${proxyUrl}/api/weather/kelly?locationId=miami_mia`);
        expect(requested.headers.get("x-weather-kelly-proxy")).toBe("cloudflare-worker");
        expect(response.status).toBe(200);
        await expect(response.json()).resolves.toEqual({ proxied: true });
    });
    test("proxies Kelly stream requests when Kelly server is configured", async () => {
        const proxyUrl = "https://kelly-proxy.example";
        const env = createEnv({ KELLY_SERVER_BASE_URL: proxyUrl });
        const context = createContext();
        const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("proxied-stream", { status: 200 }));
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/kelly/stream?locationId=toronto_yyz", {
            headers: { Upgrade: "websocket" },
        }), env, context);
        expect(fetchMock).toHaveBeenCalledTimes(1);
        const [requested] = fetchMock.mock.calls[0];
        expect(requested).toBeInstanceOf(Request);
        expect(requested.url).toBe(`${proxyUrl}/api/weather/kelly/stream?locationId=toronto_yyz`);
        expect(requested.headers.get("x-weather-kelly-proxy")).toBe("cloudflare-worker");
        expect(response.status).toBe(200);
        await expect(response.text()).resolves.toBe("proxied-stream");
    });
    test("does not proxy legacy Kelly stream locations through the bridge anymore", async () => {
        const env = createEnv();
        const context = createTrackedContext();
        const fetchMock = vi.spyOn(globalThis, "fetch");
        const createKellyStream = vi.fn(async (locationId, _options, onMessage) => {
            onMessage({
                type: "status",
                generatedAt: "2026-04-11T01:02:05.000Z",
                state: "connected",
                reasonCode: "ws_connected",
                message: "legacy stream connected locally",
            });
            return {
                close: vi.fn(),
            };
        });
        MockWebSocketPair.lastPair = null;
        vi.stubGlobal("WebSocketPair", MockWebSocketPair);
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                createKellyStream = createKellyStream;
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/kelly/stream?locationId=miami_mia", {
            headers: {
                Upgrade: "websocket",
            },
        }), env, context);
        expect(fetchMock).not.toHaveBeenCalled();
        expect(response.headers.get("x-worker-websocket-upgrade")).toBe("101");
        expect(createKellyStream).toHaveBeenCalledWith("miami_mia", expect.any(Object), expect.any(Function));
        await context.flush();
        const server = MockWebSocketPair.lastPair?.[1];
        expect(server).toBeTruthy();
        if (!server) {
            throw new Error("Expected worker stream server socket to exist.");
        }
        expect(server.sent).toEqual(expect.arrayContaining([
            expect.objectContaining({
                type: "status",
                state: "connected",
                reasonCode: "ws_connected",
            }),
        ]));
    });
    test("edge-caches stable dashboard responses while upstream data is revalidating in background", async () => {
        const edgeCache = createEdgeCache();
        vi.stubGlobal("caches", { default: edgeCache });
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                async getHourly() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        fetchedAt: "2026-04-09T00:00:00.000Z",
                        sourceObservedAt: null,
                        mode: "1h",
                        periodHours: 1,
                        sourceType: "week-table-1h",
                        stale: false,
                        freshness: "revalidating",
                        pageUrl: "https://example.com/week",
                        parserVersion: "test",
                        items: [],
                        fieldCoverage: {},
                        partial: false,
                        warnings: [],
                        cacheHit: true,
                        current: null,
                    };
                }
                async getWeatherReport() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        pageUrl: "https://example.com/week",
                        parserVersion: "test",
                        available: true,
                        titleEn: "Report",
                        sourceTextEn: "Report",
                        textZh: "Report",
                        metrics: {},
                        warnings: [],
                        fetchedAt: "2026-04-09T00:00:00.000Z",
                        sourceObservedAt: null,
                        stale: false,
                        freshness: "fresh",
                        cacheHit: true,
                    };
                }
                async getMultiModelStatus() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        pageFetchedAt: null,
                        imageFetchedAt: null,
                        imageUrlFound: false,
                        cacheHit: false,
                        stale: false,
                        lastError: null,
                        lastSuccessAt: null,
                        imageUrl: null,
                        pageUrl: "https://example.com/multimodel",
                    };
                }
                async getMultiModelDistribution() {
                    return {
                        warnings: [],
                        freshness: "fresh",
                    };
                }
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/dashboard?locationId=toronto_yyz"), createEnv(), createContext());
        const payload = await response.json();
        expect(response.status).toBe(200);
        expect(response.headers.get("cache-control")).toContain("s-maxage=30");
        expect(payload).toMatchObject({
            sync: {
                state: "fresh",
                freshness: "fresh",
            },
            hourly: {
                freshness: "revalidating",
            },
        });
        expect(edgeCache.put).toHaveBeenCalled();
    });
    test("does not edge-cache fallback_error insight responses", async () => {
        const edgeCache = createEdgeCache();
        vi.stubGlobal("caches", { default: edgeCache });
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                async getMultiModelInsight() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        fetchedAt: "2026-04-09T00:00:00.000Z",
                        pageUrl: "https://example.com/multimodel",
                        selectedTimestamp: "2026-04-09T09:00:00-04:00",
                        availableTimestamps: ["2026-04-09T09:00:00-04:00"],
                        referenceTemperature: {
                            mode: "selected-model-mean",
                            temperatureC: 10,
                            label: "10C",
                        },
                        closestModel: null,
                        rankedModels: [],
                        peakTimeDistribution: [],
                        matchedModels: { toleranceC: 0.5, models: [] },
                        dayPeakCandidates: { top: [] },
                        modelInventory: [],
                        chart: {
                            chartFormat: "highcharts",
                            chartEndpoint: "https://example.com/chart",
                            pageFetchedAt: "2026-04-09T00:00:00.000Z",
                            parserVersion: "test",
                        },
                        sourceType: "meteoblue-page-highcharts",
                        stale: true,
                        freshness: "fallback_error",
                        cacheHit: true,
                        warnings: ["Serving stale page-derived multimodel insights because the latest highcharts refresh failed."],
                    };
                }
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/multimodel/insights?locationId=toronto_yyz"), createEnv(), createContext());
        const payload = await response.json();
        expect(response.status).toBe(200);
        expect(response.headers.get("cache-control")).toContain("no-store");
        expect(payload).toMatchObject({
            stale: true,
            freshness: "fallback_error",
        });
        expect(edgeCache.put).not.toHaveBeenCalled();
    });
    test("does not edge-cache revalidating multimodel status responses", async () => {
        const edgeCache = createEdgeCache();
        vi.stubGlobal("caches", { default: edgeCache });
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                async getMultiModelStatus() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        displayUnit: "C",
                        fallbackDisplayUnit: "C",
                        pageFetchedAt: "2026-04-09T00:00:00.000Z",
                        imageFetchedAt: "2026-04-09T00:00:00.000Z",
                        imageUrlFound: true,
                        cacheHit: true,
                        stale: false,
                        freshness: "revalidating",
                        imageStatus: "ready",
                        analysisStatus: "revalidating",
                        lastError: null,
                        lastSuccessAt: "2026-04-09T00:00:00.000Z",
                        imageUrl: "https://example.com/multimodel.png",
                        pageUrl: "https://example.com/multimodel",
                    };
                }
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/multimodel/status?locationId=toronto_yyz"), createEnv(), createContext());
        const payload = await response.json();
        expect(response.status).toBe(200);
        expect(response.headers.get("cache-control")).toContain("no-store");
        expect(payload).toMatchObject({
            freshness: "revalidating",
            analysisStatus: "revalidating",
        });
        expect(edgeCache.put).not.toHaveBeenCalled();
    });
    test("dashboard does not trigger multimodel distribution warmup", async () => {
        const getMultiModelDistribution = vi.fn().mockResolvedValue({
            warnings: [],
            freshness: "fresh",
        });
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                getMultiModelDistribution = getMultiModelDistribution;
                async getHourly() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        fetchedAt: "2026-04-09T00:00:00.000Z",
                        sourceObservedAt: null,
                        mode: "1h",
                        periodHours: 1,
                        sourceType: "week-table-1h",
                        stale: false,
                        freshness: "fresh",
                        pageUrl: "https://example.com/week",
                        parserVersion: "test",
                        items: [],
                        fieldCoverage: {},
                        partial: false,
                        warnings: [],
                        cacheHit: true,
                        current: null,
                    };
                }
                async getWeatherReport() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        pageUrl: "https://example.com/week",
                        parserVersion: "test",
                        available: true,
                        titleEn: "Report",
                        sourceTextEn: "Report",
                        textZh: "Report",
                        metrics: {},
                        warnings: [],
                        fetchedAt: "2026-04-09T00:00:00.000Z",
                        sourceObservedAt: null,
                        stale: false,
                        freshness: "fresh",
                        cacheHit: true,
                    };
                }
                async getMultiModelStatus() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        displayUnit: "C",
                        fallbackDisplayUnit: "C",
                        pageFetchedAt: null,
                        imageFetchedAt: null,
                        imageUrlFound: false,
                        cacheHit: false,
                        stale: false,
                        freshness: "fresh",
                        imageStatus: "unavailable",
                        analysisStatus: "unavailable",
                        lastError: null,
                        lastSuccessAt: null,
                        imageUrl: null,
                        pageUrl: "https://example.com/multimodel",
                    };
                }
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/dashboard?locationId=toronto_yyz"), createEnv(), createContext());
        expect(response.status).toBe(200);
        expect(getMultiModelDistribution).not.toHaveBeenCalled();
    });
    test("edge-caches fresh dashboard responses", async () => {
        const edgeCache = createEdgeCache();
        vi.stubGlobal("caches", { default: edgeCache });
        vi.doMock("../src/providers/meteoblue/service.js", () => {
            class MockMeteoblueWeatherService {
                async getHourly() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        fetchedAt: "2026-04-09T00:00:00.000Z",
                        sourceObservedAt: null,
                        mode: "1h",
                        periodHours: 1,
                        sourceType: "week-table-1h",
                        stale: false,
                        freshness: "fresh",
                        pageUrl: "https://example.com/week",
                        parserVersion: "test",
                        items: [],
                        fieldCoverage: {},
                        partial: false,
                        warnings: [],
                        cacheHit: true,
                        current: null,
                    };
                }
                async getWeatherReport() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        pageUrl: "https://example.com/week",
                        parserVersion: "test",
                        available: true,
                        titleEn: "Report",
                        sourceTextEn: "Report",
                        textZh: "Report",
                        metrics: {},
                        warnings: [],
                        fetchedAt: "2026-04-09T00:00:00.000Z",
                        sourceObservedAt: null,
                        stale: false,
                        freshness: "fresh",
                        cacheHit: true,
                    };
                }
                async getMultiModelStatus() {
                    return {
                        location: { id: "toronto_yyz", name: "Toronto Pearson International Airport", timezone: "America/Toronto" },
                        displayUnit: "C",
                        fallbackDisplayUnit: "C",
                        pageFetchedAt: null,
                        imageFetchedAt: null,
                        imageUrlFound: false,
                        cacheHit: false,
                        stale: false,
                        freshness: "fresh",
                        imageStatus: "unavailable",
                        analysisStatus: "unavailable",
                        lastError: null,
                        lastSuccessAt: null,
                        imageUrl: null,
                        pageUrl: "https://example.com/multimodel",
                    };
                }
                async getMultiModelDistribution() {
                    return {
                        warnings: [],
                        freshness: "fresh",
                    };
                }
            }
            return { MeteoblueWeatherService: MockMeteoblueWeatherService };
        });
        const worker = await loadWorker();
        const response = await worker.fetch(new Request("https://lukaluka.fun/api/weather/dashboard?locationId=toronto_yyz"), createEnv(), createContext());
        const payload = await response.json();
        expect(response.status).toBe(200);
        expect(response.headers.get("cache-control")).toContain("s-maxage=30");
        expect(payload).toMatchObject({
            sync: {
                state: "fresh",
                freshness: "fresh",
            },
        });
        expect(edgeCache.put).toHaveBeenCalledTimes(1);
    });
});
