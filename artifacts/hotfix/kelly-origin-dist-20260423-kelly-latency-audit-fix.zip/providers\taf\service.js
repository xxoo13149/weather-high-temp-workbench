import * as cheerio from "cheerio";
import { fetchJson, fetchText } from "../../lib/http.js";
import { resolveMetarStationId } from "../metar/service.js";
const TAF_API_BASE_URL = "https://aviationweather.gov/api/data/taf";
const TAF_SOURCE_URL_BASE = `${TAF_API_BASE_URL}?format=json&ids=`;
const DECODED_TAF_SOURCE_URL_BASE = "https://metarcentral.com/airport";
const emptyTafSnapshot = () => ({
    forecast: null,
    forecasts: [],
});
const toIsoTime = (value) => {
    if (typeof value === "string" && value.trim()) {
        const parsed = new Date(value);
        return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
    }
    if (typeof value === "number" && Number.isFinite(value)) {
        const millis = value > 1e12 ? value : value * 1000;
        const parsed = new Date(millis);
        return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
    }
    return null;
};
const buildOfficialTafSourceUrl = (stationId) => `${TAF_SOURCE_URL_BASE}${encodeURIComponent(stationId)}`;
const buildDecodedTafSourceUrl = (stationId) => `${DECODED_TAF_SOURCE_URL_BASE}/${encodeURIComponent(stationId)}/taf`;
const convertVisibilityToKm = (value) => {
    if (typeof value === "number" && Number.isFinite(value)) {
        return Number.parseFloat((value * 1.60934).toFixed(1));
    }
    if (typeof value === "string") {
        const normalized = value.trim();
        if (!normalized) {
            return null;
        }
        if (normalized === "6+" || normalized.toUpperCase() === "P6SM") {
            return 10;
        }
        const parsed = Number.parseFloat(normalized.replace(/[^0-9.]/g, ""));
        if (Number.isFinite(parsed)) {
            return Number.parseFloat((parsed * 1.60934).toFixed(1));
        }
    }
    return null;
};
const formatCloudLayer = (layer) => {
    const cover = typeof layer.cover === "string" ? layer.cover.trim().toUpperCase() : "";
    const type = typeof layer.type === "string" ? layer.type.trim().toUpperCase() : "";
    const base = typeof layer.base === "number" && Number.isFinite(layer.base)
        ? String(Math.max(0, Math.round(layer.base / 100))).padStart(3, "0")
        : "";
    if (!cover) {
        return null;
    }
    return `${cover}${base}${type}`;
};
const parseDecodedExplanations = (html) => {
    const $ = cheerio.load(html);
    const explanations = [];
    $("h5").each((_, element) => {
        const label = $(element).text().replace(/\s+/g, " ").trim().toLowerCase();
        if (!label.includes("plain english explanation")) {
            return;
        }
        const description = $(element).next("p").text().replace(/\s+/g, " ").trim();
        if (description) {
            explanations.push(description);
        }
    });
    return explanations;
};
const resolveFlightCategoryFromExplanation = (value) => {
    if (!value) {
        return null;
    }
    const normalized = value.toUpperCase();
    if (normalized.includes("LIFR")) {
        return "LIFR";
    }
    if (normalized.includes("MVFR") || normalized.includes("MARGINAL VFR")) {
        return "MVFR";
    }
    if (normalized.includes("IFR")) {
        return "IFR";
    }
    if (normalized.includes("VFR")) {
        return "VFR";
    }
    return null;
};
const deriveFlightCategory = (visibilityKm, clouds) => {
    const ceilings = clouds
        .map((layer) => {
        const cover = layer.slice(0, 3);
        if (cover !== "BKN" && cover !== "OVC" && cover !== "VV0") {
            return null;
        }
        const base = Number.parseInt(layer.slice(3, 6), 10);
        return Number.isFinite(base) ? base * 100 : null;
    })
        .filter((value) => typeof value === "number" && Number.isFinite(value));
    const ceilingFt = ceilings.length > 0 ? Math.min(...ceilings) : null;
    if ((visibilityKm !== null && visibilityKm < 1.6) || (ceilingFt !== null && ceilingFt < 500)) {
        return "LIFR";
    }
    if ((visibilityKm !== null && visibilityKm < 4.8) || (ceilingFt !== null && ceilingFt < 1_000)) {
        return "IFR";
    }
    if ((visibilityKm !== null && visibilityKm <= 8) || (ceilingFt !== null && ceilingFt <= 3_000)) {
        return "MVFR";
    }
    if (visibilityKm !== null || ceilingFt !== null) {
        return "VFR";
    }
    return null;
};
const resolveChangeLabel = (forecast) => {
    if (typeof forecast.fcstChange === "string" && forecast.fcstChange.trim()) {
        return forecast.fcstChange.trim().toUpperCase();
    }
    if (typeof forecast.probability === "number" && Number.isFinite(forecast.probability)) {
        return `PROB${forecast.probability}`;
    }
    return "BASE";
};
const resolveActiveForecastIndex = (forecasts) => {
    if (forecasts.length === 0) {
        return -1;
    }
    const nowSeconds = Math.floor(Date.now() / 1000);
    const currentIndex = forecasts.findIndex((forecast) => {
        const timeFrom = typeof forecast.timeFrom === "number" ? forecast.timeFrom : null;
        const timeTo = typeof forecast.timeTo === "number" ? forecast.timeTo : null;
        return timeFrom !== null && timeTo !== null && nowSeconds >= timeFrom && nowSeconds < timeTo;
    });
    if (currentIndex >= 0) {
        return currentIndex;
    }
    const nextIndex = forecasts.findIndex((forecast) => typeof forecast.timeFrom === "number" && forecast.timeFrom > nowSeconds);
    return nextIndex >= 0 ? nextIndex : 0;
};
export const fetchTafSnapshot = async (location) => {
    const stationId = resolveMetarStationId(location.id);
    if (!stationId) {
        return emptyTafSnapshot();
    }
    const officialSourceUrl = buildOfficialTafSourceUrl(stationId);
    const sourceUrl = buildDecodedTafSourceUrl(stationId);
    const payload = await fetchJson(officialSourceUrl);
    if (!Array.isArray(payload) || payload.length === 0) {
        return emptyTafSnapshot();
    }
    const latest = payload[0];
    if (!latest || !Array.isArray(latest.fcsts) || latest.fcsts.length === 0) {
        return emptyTafSnapshot();
    }
    const tafForecasts = latest.fcsts;
    let decodedExplanations = [];
    try {
        decodedExplanations = parseDecodedExplanations(await fetchText(sourceUrl));
    }
    catch {
        decodedExplanations = [];
    }
    const activeForecastIndex = resolveActiveForecastIndex(tafForecasts);
    const forecasts = tafForecasts.map((forecast, index) => {
        const clouds = Array.isArray(forecast.clouds)
            ? forecast.clouds.map((layer) => formatCloudLayer(layer)).filter((value) => Boolean(value))
            : [];
        const visibilityKm = convertVisibilityToKm(forecast.visib);
        const plainEnglish = decodedExplanations.length === tafForecasts.length
            ? decodedExplanations[index] ?? null
            : index === activeForecastIndex
                ? decodedExplanations[0] ?? null
                : null;
        const flightCategory = resolveFlightCategoryFromExplanation(plainEnglish) ?? deriveFlightCategory(visibilityKm, clouds);
        return {
            changeLabel: resolveChangeLabel(forecast),
            plainEnglish,
            timeFrom: toIsoTime(forecast.timeFrom),
            timeTo: toIsoTime(forecast.timeTo),
            visibilityKm,
            clouds,
            windDirectionDegrees: typeof forecast.wdir === "number" && Number.isFinite(forecast.wdir) ? forecast.wdir : null,
            windSpeedKts: typeof forecast.wspd === "number" && Number.isFinite(forecast.wspd) ? forecast.wspd : null,
            windGustKts: typeof forecast.wgst === "number" && Number.isFinite(forecast.wgst) ? forecast.wgst : null,
            flightCategory,
        };
    });
    const activeForecast = forecasts[activeForecastIndex] ?? forecasts[0] ?? null;
    const fetchedAt = new Date().toISOString();
    return {
        forecast: {
            location,
            stationId,
            stationName: typeof latest.name === "string" ? latest.name : null,
            issuedAt: toIsoTime(latest.issueTime),
            validFrom: toIsoTime(latest.validTimeFrom),
            validTo: toIsoTime(latest.validTimeTo),
            rawTaf: typeof latest.rawTAF === "string" ? latest.rawTAF : null,
            sourceUrl,
            officialSourceUrl,
            activeForecast,
            fetchedAt,
            stale: false,
            freshness: "fresh",
            cacheHit: false,
        },
        forecasts,
    };
};
