import { DEFAULT_LOCATION, LOCATION_REGISTRY } from "../config.js";
import { AppError, isAppError } from "../domain/errors.js";
import { buildDashboardEnhancements, buildLocationDirectory, buildMetricsText, buildSystemStatusResponse, getLocationSourceContract, } from "../operational-metadata.js";
import { MeteoblueWeatherService } from "../providers/meteoblue/service.js";
import { CloudflareFavoritesStore, InMemoryFavoritesStore } from "./favorites-store.js";
let runtimeBuildId = null;
let runtimeStartedAt = null;
let servicePromise = null;
const KELLY_PROXY_FAILURE_THRESHOLD = 3;
const KELLY_PROXY_FAILURE_WINDOW_MS = 60_000;
const KELLY_PROXY_OPEN_DURATION_MS = 5 * 60_000;
const KELLY_PROXY_GET_TIMEOUT_MS = 12_000;
const DASHBOARD_PROXY_GET_TIMEOUT_MS = 12_000;
const KELLY_PROXY_STREAM_TIMEOUT_MS = 6_000;
const createKellyProxyCircuitTracker = () => ({
    failureTimestamps: [],
    consecutiveFailures: 0,
    openUntil: null,
    halfOpenProbeInFlight: false,
    lastOriginSuccessAt: null,
    lastOriginFailureAt: null,
    lastOriginFailureCode: null,
    localFallbackActive: false,
});
const kellyGetProxyCircuit = createKellyProxyCircuitTracker();
const kellyStreamProxyCircuit = createKellyProxyCircuitTracker();
const dashboardGetProxyCircuit = createKellyProxyCircuitTracker();
const ensureRuntimeMetadata = () => {
    const rawBuildId = typeof process !== "undefined" && process.env && typeof process.env.BUILD_ID === "string"
        ? process.env.BUILD_ID.trim()
        : "";
    if (!runtimeBuildId) {
        const generatedBuildId = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
            ? `worker-${crypto.randomUUID()}`
            : `worker-${Math.random().toString(36).slice(2, 10)}`;
        runtimeBuildId = rawBuildId || generatedBuildId;
    }
    if (!runtimeStartedAt) {
        runtimeStartedAt = new Date().toISOString();
    }
    return {
        buildId: runtimeBuildId,
        startedAt: runtimeStartedAt,
    };
};
const getService = async (env) => {
    if (!servicePromise) {
        const favoritesStore = env.FAVORITES_KV
            ? new CloudflareFavoritesStore(env.FAVORITES_KV)
            : new InMemoryFavoritesStore();
        servicePromise = Promise.resolve(new MeteoblueWeatherService({ favoritesStore }));
    }
    return await servicePromise;
};
const parseMode = (raw) => {
    if (raw === null || raw === "" || raw === "1h") {
        return "1h";
    }
    if (raw === "3h") {
        return "3h";
    }
    throw new AppError(400, "BAD_REQUEST", "Query parameter 'mode' must be either '1h' or '3h'.");
};
const parseLimit = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    const value = Number.parseInt(raw, 10);
    if (!Number.isFinite(value) || value <= 0) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'limit' must be a positive integer.");
    }
    return value;
};
const parseAllowStale = (raw) => raw === "true" || raw === "1";
const parseTimestamp = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    const parsed = new Date(raw);
    if (Number.isNaN(parsed.getTime())) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'timestamp' must be a valid ISO timestamp.");
    }
    return raw;
};
const parseBucketSize = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    const value = Number.parseFloat(raw);
    if (!Number.isFinite(value) || value <= 0) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'bucketSize' must be a positive number.");
    }
    return value;
};
const parseFloatNumber = (raw, message) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    const value = Number.parseFloat(raw);
    if (!Number.isFinite(value)) {
        throw new AppError(400, "BAD_REQUEST", message);
    }
    return value;
};
const parseActualTemperatureC = (raw) => parseFloatNumber(raw, "Query parameter 'actualTemperatureC' must be a finite number.");
const parseKellyTargetDate = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'targetDate' must use YYYY-MM-DD format.");
    }
    return raw;
};
const parseBankroll = (raw) => {
    const value = parseFloatNumber(raw, "Query parameter 'bankroll' must be a positive number.");
    if (value === undefined) {
        return undefined;
    }
    if (value <= 0) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'bankroll' must be a positive number.");
    }
    return value;
};
const parseKellyRiskMode = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    if (raw === "conservative" || raw === "balanced" || raw === "aggressive") {
        return raw;
    }
    throw new AppError(400, "BAD_REQUEST", "Query parameter 'riskMode' must be conservative, balanced, or aggressive.");
};
const parseKellyMinEdge = (raw) => {
    const value = parseFloatNumber(raw, "Query parameter 'minEdge' must be between 0 and 1.");
    if (value === undefined) {
        return undefined;
    }
    if (value < 0 || value > 1) {
        throw new AppError(400, "BAD_REQUEST", "Query parameter 'minEdge' must be between 0 and 1.");
    }
    return value;
};
const parseForceRefresh = (raw) => {
    if (raw === null || raw === "") {
        return undefined;
    }
    if (raw === "true" || raw === "1") {
        return true;
    }
    if (raw === "false" || raw === "0") {
        return false;
    }
    throw new AppError(400, "BAD_REQUEST", "Query parameter 'forceRefresh' must be boolean.");
};
const parseQueryLocationId = (raw) => {
    if (raw === null || raw === "") {
        return DEFAULT_LOCATION;
    }
    const locationId = raw.trim();
    if (!(locationId in LOCATION_REGISTRY)) {
        throw new AppError(400, "BAD_REQUEST", `Query parameter 'locationId' is not supported: '${raw}'.`);
    }
    return locationId;
};
const parseFavoriteBody = (raw) => {
    if (typeof raw !== "object" || raw === null || !("favorite" in raw)) {
        throw new AppError(400, "BAD_REQUEST", "Request body must include a boolean 'favorite' field.");
    }
    const value = raw.favorite;
    if (typeof value !== "boolean") {
        throw new AppError(400, "BAD_REQUEST", "Request body field 'favorite' must be boolean.");
    }
    return value;
};
const parseKellyOptions = (url) => ({
    targetDate: parseKellyTargetDate(url.searchParams.get("targetDate")),
    bankroll: parseBankroll(url.searchParams.get("bankroll")),
    riskMode: parseKellyRiskMode(url.searchParams.get("riskMode")),
    minEdge: parseKellyMinEdge(url.searchParams.get("minEdge")),
    actualTemperatureC: parseActualTemperatureC(url.searchParams.get("actualTemperatureC")),
    selectedHourTimestamp: parseTimestamp(url.searchParams.get("selectedHour")),
    forceRefresh: parseForceRefresh(url.searchParams.get("forceRefresh")),
});
const DEFAULT_CACHE_CONTROL = "no-store, max-age=0";
const EDGE_CACHE_TTL_SECONDS = {
    hourly: 45,
    report: 45,
    dashboard: 30,
    multimodelStatus: 45,
    multimodelInsight: 90,
    multimodelDistribution: 90,
};
const buildEdgeCacheControl = (ttlSeconds) => `public, max-age=0, s-maxage=${ttlSeconds}, stale-while-revalidate=${ttlSeconds}`;
const jsonResponse = (payload, status = 200, headers) => new Response(JSON.stringify(payload), {
    status,
    headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": DEFAULT_CACHE_CONTROL,
        ...(headers ?? {}),
    },
});
const withEdgeJsonCache = async (request, ctx, ttlSeconds, loader, options) => {
    const edgeCache = typeof caches === "undefined" ? null : (caches.default ?? null);
    if (!edgeCache) {
        return jsonResponse(await loader());
    }
    const cacheKey = new Request(request.url, {
        method: "GET",
    });
    const cachedResponse = await edgeCache.match(cacheKey);
    if (cachedResponse) {
        return cachedResponse;
    }
    const cacheControl = buildEdgeCacheControl(ttlSeconds);
    const payload = await loader();
    if (options?.shouldCache && !options.shouldCache(payload)) {
        return jsonResponse(payload);
    }
    const response = jsonResponse(payload, 200, {
        "cache-control": cacheControl,
        "cdn-cache-control": cacheControl,
    });
    ctx.waitUntil(edgeCache.put(cacheKey, response.clone()));
    return response;
};
const hasFreshFreshness = (payload) => typeof payload !== "object" ||
    payload === null ||
    !("freshness" in payload) ||
    payload.freshness === "fresh";
const hasFreshDashboardSync = (payload) => typeof payload === "object" &&
    payload !== null &&
    "sync" in payload &&
    typeof payload.sync?.freshness === "string" &&
    payload.sync.freshness === "fresh";
const resolvePayloadFreshness = (payload, staleFallback) => {
    if (typeof payload === "object" && payload !== null && typeof payload.freshness === "string") {
        return payload.freshness;
    }
    return staleFallback ? "fallback_error" : "fresh";
};
const handleError = (error) => {
    if (isAppError(error)) {
        return jsonResponse(error.toPayload(), error.statusCode);
    }
    const fallback = new AppError(500, "INTERNAL_SERVER_ERROR", "Unexpected server error.");
    return jsonResponse(fallback.toPayload(), 500);
};
const sendSocketMessage = (socket, message) => {
    try {
        socket.send(JSON.stringify(message));
    }
    catch {
        socket.close();
    }
};
const createWebSocketUpgradeResponse = (client) => {
    try {
        return new Response(null, {
            status: 101,
            ...{ webSocket: client },
        });
    }
    catch {
        const response = new Response(null, {
            status: 200,
            headers: {
                "x-worker-websocket-upgrade": "101",
            },
        });
        Object.defineProperty(response, "webSocket", {
            configurable: true,
            value: client,
        });
        return response;
    }
};
const resolveKellyServerBaseUrl = (env) => {
    const raw = env.KELLY_SERVER_BASE_URL?.trim();
    if (!raw) {
        return null;
    }
    try {
        const parsed = new URL(raw);
        return parsed.toString().replace(/\/+$/, "");
    }
    catch {
        throw new AppError(500, "INVALID_KELLY_SERVER_BASE_URL", "Worker env 'KELLY_SERVER_BASE_URL' must be a valid absolute URL.");
    }
};
const resolveKellyStreamProxyMode = (env) => {
    const raw = env.KELLY_STREAM_PROXY_MODE?.trim().toLowerCase();
    if (!raw) {
        return "canary";
    }
    if (raw === "local-only" || raw === "canary" || raw === "remote-first") {
        return raw;
    }
    throw new AppError(500, "INVALID_KELLY_STREAM_PROXY_MODE", "Worker env 'KELLY_STREAM_PROXY_MODE' must be local-only, canary, or remote-first.");
};
const buildOriginProxyRequest = (request, env) => {
    const baseUrl = resolveKellyServerBaseUrl(env);
    if (!baseUrl) {
        return null;
    }
    const incomingUrl = new URL(request.url);
    const upstreamUrl = `${baseUrl}${incomingUrl.pathname}${incomingUrl.search}`;
    const headers = new Headers(request.headers);
    headers.set("x-weather-kelly-proxy", "cloudflare-worker");
    if (request.headers.get("Upgrade")?.toLowerCase() === "websocket") {
        headers.set("Connection", "Upgrade");
        headers.set("Upgrade", "websocket");
    }
    return new Request(upstreamUrl, {
        method: request.method,
        headers,
    });
};
const pruneKellyProxyFailures = (circuit, now = Date.now()) => {
    circuit.failureTimestamps = circuit.failureTimestamps.filter((timestamp) => now - timestamp <= KELLY_PROXY_FAILURE_WINDOW_MS);
};
const resolveKellyProxyCircuitState = (circuit) => {
    if (circuit.openUntil !== null) {
        return Date.now() < circuit.openUntil ? "open" : "half-open";
    }
    return circuit.halfOpenProbeInFlight ? "half-open" : "closed";
};
const recordKellyOriginSuccess = (circuit) => {
    circuit.failureTimestamps = [];
    circuit.consecutiveFailures = 0;
    circuit.openUntil = null;
    circuit.halfOpenProbeInFlight = false;
    circuit.lastOriginSuccessAt = new Date().toISOString();
    circuit.localFallbackActive = false;
};
const recordKellyOriginFailure = (circuit, reasonCode) => {
    const now = Date.now();
    pruneKellyProxyFailures(circuit, now);
    circuit.failureTimestamps.push(now);
    circuit.consecutiveFailures += 1;
    circuit.lastOriginFailureAt = new Date(now).toISOString();
    circuit.lastOriginFailureCode = reasonCode;
    circuit.localFallbackActive = true;
    circuit.halfOpenProbeInFlight = false;
    if (circuit.failureTimestamps.length >= KELLY_PROXY_FAILURE_THRESHOLD) {
        circuit.openUntil = now + KELLY_PROXY_OPEN_DURATION_MS;
    }
};
const shouldBypassKellyOrigin = (circuit) => {
    if (circuit.openUntil === null) {
        return false;
    }
    if (Date.now() < circuit.openUntil) {
        return true;
    }
    if (circuit.halfOpenProbeInFlight) {
        return true;
    }
    circuit.halfOpenProbeInFlight = true;
    return false;
};
const isKellyOriginJsonResponse = (response) => (response.headers.get("content-type") ?? "").toLowerCase().includes("application/json");
const readKellyOriginJsonError = async (response) => {
    try {
        const payload = (await response.clone().json());
        if (typeof payload !== "object" || payload === null) {
            return null;
        }
        const record = payload;
        return {
            code: typeof record.code === "string" ? record.code : undefined,
            message: typeof record.message === "string" ? record.message : undefined,
        };
    }
    catch {
        return null;
    }
};
const isKellyOriginLocationVersionSkew = async (request, response) => {
    if (response.status !== 400 || !isKellyOriginJsonResponse(response)) {
        return false;
    }
    const rawLocationId = new URL(request.url).searchParams.get("locationId")?.trim();
    if (!rawLocationId || !(rawLocationId in LOCATION_REGISTRY)) {
        return false;
    }
    const payload = await readKellyOriginJsonError(response);
    return (payload?.code === "BAD_REQUEST" &&
        typeof payload.message === "string" &&
        payload.message.includes("Query parameter 'locationId' is not supported"));
};
const kellyOriginPayloadHasMetarObservation = (payload) => {
    if (typeof payload !== "object" || payload === null) {
        return false;
    }
    const metarObservation = payload.weatherEvidence?.metarObservation;
    if (typeof metarObservation !== "object" || metarObservation === null) {
        return false;
    }
    const stationId = metarObservation.stationId;
    if (typeof stationId === "string" && stationId.trim() !== "") {
        return true;
    }
    return Number.isFinite(metarObservation.temperatureC);
};
const isKellyOriginMetarContractSkew = async (request, response) => {
    if (!response.ok || !isKellyOriginJsonResponse(response)) {
        return false;
    }
    const rawLocationId = new URL(request.url).searchParams.get("locationId")?.trim();
    if (!rawLocationId || !(rawLocationId in LOCATION_REGISTRY)) {
        return false;
    }
    const locationId = rawLocationId;
    const contract = getLocationSourceContract(locationId);
    if (contract.currentSources.primaryObservation.key !== "aviationweather-metar" ||
        !contract.currentSources.primaryObservation.stationCode) {
        return false;
    }
    const payload = await response.clone().json().catch(() => null);
    return !kellyOriginPayloadHasMetarObservation(payload);
};
const dashboardOriginPayloadHasMetarObservation = (payload) => {
    if (typeof payload !== "object" || payload === null) {
        return false;
    }
    const metarObservation = payload.metar?.observation;
    if (typeof metarObservation !== "object" || metarObservation === null) {
        return false;
    }
    const stationId = metarObservation.stationId;
    if (typeof stationId === "string" && stationId.trim() !== "") {
        return true;
    }
    return Number.isFinite(metarObservation.temperatureC);
};
const isDashboardOriginMetarContractSkew = async (request, response) => {
    if (!response.ok || !isKellyOriginJsonResponse(response)) {
        return false;
    }
    const rawLocationId = new URL(request.url).searchParams.get("locationId")?.trim();
    if (!rawLocationId || !(rawLocationId in LOCATION_REGISTRY)) {
        return false;
    }
    const locationId = rawLocationId;
    const contract = getLocationSourceContract(locationId);
    if (contract.currentSources.primaryObservation.key !== "aviationweather-metar" ||
        !contract.currentSources.primaryObservation.stationCode) {
        return false;
    }
    const payload = await response.clone().json().catch(() => null);
    return !dashboardOriginPayloadHasMetarObservation(payload);
};
const logOriginProxyResult = (request, details) => {
    const url = new URL(request.url);
    const log = details.originMode === "remote" ? console.info : console.warn;
    log("[kelly-proxy]", {
        requestKind: details.requestKind,
        originMode: details.originMode,
        reasonCode: details.reasonCode,
        circuitState: details.circuitState,
        locationId: url.searchParams.get("locationId"),
        targetDate: url.searchParams.get("targetDate"),
    });
};
const fetchKellyOriginGet = async (request, env, timeoutMs) => {
    const proxyRequest = buildOriginProxyRequest(request, env);
    if (!proxyRequest) {
        return { kind: "unconfigured" };
    }
    if (shouldBypassKellyOrigin(kellyGetProxyCircuit)) {
        kellyGetProxyCircuit.localFallbackActive = true;
        const circuitState = resolveKellyProxyCircuitState(kellyGetProxyCircuit);
        logOriginProxyResult(request, {
            requestKind: "get",
            originMode: "local-fallback",
            reasonCode: "origin_circuit_open",
            circuitState,
        });
        return {
            kind: "fallback",
            reasonCode: "origin_circuit_open",
            circuitState,
        };
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
        controller.abort();
    }, timeoutMs);
    try {
        const response = await fetch(new Request(proxyRequest, {
            signal: controller.signal,
        }));
        if (await isKellyOriginMetarContractSkew(request, response)) {
            const reasonCode = "origin_metar_contract_skew";
            recordKellyOriginFailure(kellyGetProxyCircuit, reasonCode);
            logOriginProxyResult(request, {
                requestKind: "get",
                originMode: "local-fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
            });
            return {
                kind: "fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
            };
        }
        if (response.ok) {
            recordKellyOriginSuccess(kellyGetProxyCircuit);
            logOriginProxyResult(request, {
                requestKind: "get",
                originMode: "remote",
                reasonCode: "origin_ok",
                circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
            });
            return {
                kind: "passthrough",
                response,
            };
        }
        if (await isKellyOriginLocationVersionSkew(request, response)) {
            const reasonCode = "origin_location_version_skew";
            recordKellyOriginFailure(kellyGetProxyCircuit, reasonCode);
            logOriginProxyResult(request, {
                requestKind: "get",
                originMode: "local-fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
            });
            return {
                kind: "fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
            };
        }
        if (response.status >= 400 && response.status < 500 && isKellyOriginJsonResponse(response)) {
            recordKellyOriginSuccess(kellyGetProxyCircuit);
            logOriginProxyResult(request, {
                requestKind: "get",
                originMode: "remote",
                reasonCode: `origin_status_${response.status}`,
                circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
            });
            return {
                kind: "passthrough",
                response,
            };
        }
        const reasonCode = `origin_status_${response.status}`;
        recordKellyOriginFailure(kellyGetProxyCircuit, reasonCode);
        logOriginProxyResult(request, {
            requestKind: "get",
            originMode: "local-fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
        });
        return {
            kind: "fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
        };
    }
    catch (error) {
        const reasonCode = error instanceof Error && error.name === "AbortError" ? "origin_timeout" : "origin_fetch_failed";
        recordKellyOriginFailure(kellyGetProxyCircuit, reasonCode);
        logOriginProxyResult(request, {
            requestKind: "get",
            originMode: "local-fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
        });
        return {
            kind: "fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
        };
    }
    finally {
        clearTimeout(timeoutId);
    }
};
const fetchDashboardOriginGet = async (request, env, timeoutMs) => {
    const proxyRequest = buildOriginProxyRequest(request, env);
    if (!proxyRequest) {
        return { kind: "unconfigured" };
    }
    if (shouldBypassKellyOrigin(dashboardGetProxyCircuit)) {
        dashboardGetProxyCircuit.localFallbackActive = true;
        const circuitState = resolveKellyProxyCircuitState(dashboardGetProxyCircuit);
        logOriginProxyResult(request, {
            requestKind: "dashboard",
            originMode: "local-fallback",
            reasonCode: "origin_circuit_open",
            circuitState,
        });
        return {
            kind: "fallback",
            reasonCode: "origin_circuit_open",
            circuitState,
        };
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
        controller.abort();
    }, timeoutMs);
    try {
        const response = await fetch(new Request(proxyRequest, {
            signal: controller.signal,
        }));
        if (await isKellyOriginLocationVersionSkew(request, response)) {
            const reasonCode = "origin_location_version_skew";
            recordKellyOriginFailure(dashboardGetProxyCircuit, reasonCode);
            logOriginProxyResult(request, {
                requestKind: "dashboard",
                originMode: "local-fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
            });
            return {
                kind: "fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
            };
        }
        if (await isDashboardOriginMetarContractSkew(request, response)) {
            const reasonCode = "origin_metar_contract_skew";
            recordKellyOriginFailure(dashboardGetProxyCircuit, reasonCode);
            logOriginProxyResult(request, {
                requestKind: "dashboard",
                originMode: "local-fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
            });
            return {
                kind: "fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
            };
        }
        if (response.ok) {
            recordKellyOriginSuccess(dashboardGetProxyCircuit);
            logOriginProxyResult(request, {
                requestKind: "dashboard",
                originMode: "remote",
                reasonCode: "origin_ok",
                circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
            });
            return {
                kind: "passthrough",
                response,
            };
        }
        if (response.status >= 400 && response.status < 500 && isKellyOriginJsonResponse(response)) {
            recordKellyOriginSuccess(dashboardGetProxyCircuit);
            logOriginProxyResult(request, {
                requestKind: "dashboard",
                originMode: "remote",
                reasonCode: `origin_status_${response.status}`,
                circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
            });
            return {
                kind: "passthrough",
                response,
            };
        }
        const reasonCode = `origin_status_${response.status}`;
        recordKellyOriginFailure(dashboardGetProxyCircuit, reasonCode);
        logOriginProxyResult(request, {
            requestKind: "dashboard",
            originMode: "local-fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
        });
        return {
            kind: "fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
        };
    }
    catch (error) {
        const reasonCode = error instanceof Error && error.name === "AbortError" ? "origin_timeout" : "origin_fetch_failed";
        recordKellyOriginFailure(dashboardGetProxyCircuit, reasonCode);
        logOriginProxyResult(request, {
            requestKind: "dashboard",
            originMode: "local-fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
        });
        return {
            kind: "fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
        };
    }
    finally {
        clearTimeout(timeoutId);
    }
};
const isKellyOriginWebSocketUpgrade = (response) => response.status === 101 && Boolean(response.webSocket);
const shouldAttemptKellyOriginStream = (request, env) => {
    const mode = resolveKellyStreamProxyMode(env);
    if (mode === "local-only") {
        return false;
    }
    if (mode === "remote-first") {
        return true;
    }
    return request.headers.get("x-kelly-origin-canary") === "1";
};
const fetchKellyOriginStream = async (request, env) => {
    const proxyRequest = buildOriginProxyRequest(request, env);
    if (!proxyRequest) {
        return { kind: "unconfigured" };
    }
    if (shouldBypassKellyOrigin(kellyStreamProxyCircuit)) {
        kellyStreamProxyCircuit.localFallbackActive = true;
        const circuitState = resolveKellyProxyCircuitState(kellyStreamProxyCircuit);
        logOriginProxyResult(request, {
            requestKind: "stream",
            originMode: "local-fallback",
            reasonCode: "origin_circuit_open",
            circuitState,
        });
        return {
            kind: "fallback",
            reasonCode: "origin_circuit_open",
            circuitState,
        };
    }
    const controller = new AbortController();
    let timeoutId = null;
    const fetchTask = fetch(new Request(proxyRequest, {
        signal: controller.signal,
    }))
        .then((response) => ({ kind: "response", response }))
        .catch((error) => ({ kind: "error", error }));
    const timeoutTask = new Promise((resolve) => {
        timeoutId = setTimeout(() => {
            controller.abort();
            resolve({ kind: "timeout" });
        }, KELLY_PROXY_STREAM_TIMEOUT_MS);
    });
    try {
        const settled = await Promise.race([fetchTask, timeoutTask]);
        if (settled.kind === "timeout") {
            const reasonCode = "origin_timeout";
            recordKellyOriginFailure(kellyStreamProxyCircuit, reasonCode);
            logOriginProxyResult(request, {
                requestKind: "stream",
                originMode: "local-fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(kellyStreamProxyCircuit),
            });
            return {
                kind: "fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(kellyStreamProxyCircuit),
            };
        }
        if (settled.kind === "error") {
            const reasonCode = settled.error instanceof Error && settled.error.name === "AbortError" ? "origin_timeout" : "origin_fetch_failed";
            recordKellyOriginFailure(kellyStreamProxyCircuit, reasonCode);
            logOriginProxyResult(request, {
                requestKind: "stream",
                originMode: "local-fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(kellyStreamProxyCircuit),
            });
            return {
                kind: "fallback",
                reasonCode,
                circuitState: resolveKellyProxyCircuitState(kellyStreamProxyCircuit),
            };
        }
        const response = settled.response;
        if (isKellyOriginWebSocketUpgrade(response)) {
            recordKellyOriginSuccess(kellyStreamProxyCircuit);
            logOriginProxyResult(request, {
                requestKind: "stream",
                originMode: "remote",
                reasonCode: "origin_ws_proxy",
                circuitState: resolveKellyProxyCircuitState(kellyStreamProxyCircuit),
            });
            return {
                kind: "passthrough",
                response,
            };
        }
        const reasonCode = response.status === 101 ? "origin_missing_websocket" : `origin_status_${response.status}`;
        recordKellyOriginFailure(kellyStreamProxyCircuit, reasonCode);
        logOriginProxyResult(request, {
            requestKind: "stream",
            originMode: "local-fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(kellyStreamProxyCircuit),
        });
        return {
            kind: "fallback",
            reasonCode,
            circuitState: resolveKellyProxyCircuitState(kellyStreamProxyCircuit),
        };
    }
    finally {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
    }
};
const buildKellyProxyHealth = (env) => ({
    configured: Boolean(resolveKellyServerBaseUrl(env)),
    originBaseUrl: resolveKellyServerBaseUrl(env),
    circuitState: resolveKellyProxyCircuitState(kellyGetProxyCircuit),
    consecutiveFailures: kellyGetProxyCircuit.consecutiveFailures,
    openUntil: kellyGetProxyCircuit.openUntil === null ? null : new Date(kellyGetProxyCircuit.openUntil).toISOString(),
    lastOriginSuccessAt: kellyGetProxyCircuit.lastOriginSuccessAt,
    lastOriginFailureAt: kellyGetProxyCircuit.lastOriginFailureAt,
    lastOriginFailureCode: kellyGetProxyCircuit.lastOriginFailureCode,
    localFallbackActive: kellyGetProxyCircuit.localFallbackActive,
    streamMode: resolveKellyStreamProxyMode(env),
    streamLastOriginSuccessAt: kellyStreamProxyCircuit.lastOriginSuccessAt,
    streamLastOriginFailureAt: kellyStreamProxyCircuit.lastOriginFailureAt,
    streamLastOriginFailureCode: kellyStreamProxyCircuit.lastOriginFailureCode,
    streamLocalFallbackActive: kellyStreamProxyCircuit.localFallbackActive,
    dashboardCircuitState: resolveKellyProxyCircuitState(dashboardGetProxyCircuit),
    dashboardLastOriginSuccessAt: dashboardGetProxyCircuit.lastOriginSuccessAt,
    dashboardLastOriginFailureAt: dashboardGetProxyCircuit.lastOriginFailureAt,
    dashboardLastOriginFailureCode: dashboardGetProxyCircuit.lastOriginFailureCode,
    dashboardLocalFallbackActive: dashboardGetProxyCircuit.localFallbackActive,
});
const handleKellyStream = async (request, env, ctx) => {
    if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
        return new Response("Expected Upgrade: websocket", { status: 426 });
    }
    let originAttempt = null;
    if (shouldAttemptKellyOriginStream(request, env)) {
        originAttempt = await fetchKellyOriginStream(request, env);
        if (originAttempt.kind === "passthrough") {
            return originAttempt.response;
        }
    }
    const url = new URL(request.url);
    const locationId = parseQueryLocationId(url.searchParams.get("locationId"));
    const pair = new (globalThis.WebSocketPair)();
    const client = pair[0];
    const server = pair[1];
    server.accept();
    const service = await getService(env);
    ctx.waitUntil((async () => {
        if (!service.createKellyStream) {
            sendSocketMessage(server, {
                type: "status",
                generatedAt: new Date().toISOString(),
                state: "unavailable",
                reasonCode: "upstream_error",
                message: "Kelly real-time stream is not configured.",
            });
            server.close(1011, "kelly-stream-unavailable");
            return;
        }
        try {
            const stream = await service.createKellyStream(locationId, parseKellyOptions(url), (message) => sendSocketMessage(server, originAttempt?.kind === "fallback"
                ? {
                    ...message,
                    originMode: "local-fallback",
                    circuitState: originAttempt.circuitState,
                }
                : message));
            const closeStream = async () => {
                try {
                    await stream.close();
                }
                catch {
                    // Ignore cleanup failures.
                }
            };
            server.addEventListener("close", () => {
                ctx.waitUntil(closeStream());
            });
            server.addEventListener("error", () => {
                ctx.waitUntil(closeStream());
            });
        }
        catch (error) {
            sendSocketMessage(server, {
                type: "status",
                generatedAt: new Date().toISOString(),
                state: "degraded",
                reasonCode: "upstream_error",
                message: error instanceof Error ? error.message : "Kelly realtime stream initialization failed.",
            });
            server.close(1011, "kelly-stream-error");
        }
    })());
    return createWebSocketUpgradeResponse(client);
};
const handleApiRequest = async (request, env, ctx) => {
    const url = new URL(request.url);
    const runtimeMetadata = ensureRuntimeMetadata();
    if (request.method === "GET" && url.pathname === "/healthz") {
        return jsonResponse({
            ok: true,
            service: "weather-worker",
            buildId: runtimeMetadata.buildId,
            startedAt: runtimeMetadata.startedAt,
            kellyProxy: buildKellyProxyHealth(env),
        });
    }
    if (request.method === "GET" && url.pathname === "/api/system/status") {
        return jsonResponse(buildSystemStatusResponse({
            service: "weather-worker",
            buildId: runtimeMetadata.buildId,
            startedAt: runtimeMetadata.startedAt,
            runtime: servicePromise ? (await getService(env)).getSystemStatus?.() ?? null : null,
            kellyProxy: buildKellyProxyHealth(env),
        }));
    }
    if (request.method === "GET" && url.pathname === "/metrics") {
        const status = buildSystemStatusResponse({
            service: "weather-worker",
            buildId: runtimeMetadata.buildId,
            startedAt: runtimeMetadata.startedAt,
            runtime: servicePromise ? (await getService(env)).getSystemStatus?.() ?? null : null,
            kellyProxy: buildKellyProxyHealth(env),
        });
        return new Response(buildMetricsText(status), {
            status: 200,
            headers: {
                "content-type": "text/plain; version=0.0.4; charset=utf-8",
            },
        });
    }
    if (request.method === "GET" && url.pathname === "/api/weather/kelly") {
        const originAttempt = await fetchKellyOriginGet(request, env, KELLY_PROXY_GET_TIMEOUT_MS);
        if (originAttempt.kind === "passthrough") {
            return originAttempt.response;
        }
        const service = await getService(env);
        const locationId = parseQueryLocationId(url.searchParams.get("locationId"));
        if (!service.getKellyWorkbench) {
            throw new AppError(503, "KELLY_UNAVAILABLE", "Kelly workbench is not configured.", {
                retryable: false,
            });
        }
        return jsonResponse(await service.getKellyWorkbench(locationId, parseKellyOptions(url)));
    }
    if (request.method === "GET" && url.pathname === "/api/weather/dashboard") {
        const originAttempt = await fetchDashboardOriginGet(request, env, DASHBOARD_PROXY_GET_TIMEOUT_MS);
        if (originAttempt.kind === "passthrough") {
            return originAttempt.response;
        }
    }
    const service = await getService(env);
    const locationId = parseQueryLocationId(url.searchParams.get("locationId"));
    switch (`${request.method} ${url.pathname}`) {
        case "GET /api/weather/hourly":
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.hourly, async () => await service.getHourly(locationId, parseMode(url.searchParams.get("mode")), parseLimit(url.searchParams.get("limit"))), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/weather/report":
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.report, async () => await service.getWeatherReport(locationId), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/weather/dashboard": {
            const mode = parseMode(url.searchParams.get("mode"));
            const limit = parseLimit(url.searchParams.get("limit"));
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.dashboard, async () => {
                const [hourly, multimodel, report, metar, taf] = await Promise.all([
                    service.getHourly(locationId, mode, limit),
                    service.getMultiModelStatus(locationId),
                    service.getWeatherReport(locationId),
                    service.getMetarSnapshot?.(locationId) ?? Promise.resolve({ observation: null, recentTemperatures: [] }),
                    service.getTafSnapshot?.(locationId) ?? Promise.resolve({ forecast: null, forecasts: [] }),
                ]);
                const dashboardEnhancements = buildDashboardEnhancements({
                    locationId,
                    hourly,
                    report,
                    multimodel,
                });
                const syncState = hourly.freshness === "fallback_error" || report.freshness === "fallback_error"
                    ? "fallback_error"
                    : "fresh";
                return {
                    generatedAt: new Date().toISOString(),
                    displayUnit: LOCATION_REGISTRY[locationId].fallbackDisplayUnit,
                    sync: {
                        state: syncState,
                        freshness: syncState,
                        label: syncState === "fallback_error"
                            ? "fallback_error"
                            : "synced",
                        updatedAt: hourly.fetchedAt,
                    },
                    locationDirectory: buildLocationDirectory(),
                    hourly,
                    report,
                    metar,
                    taf,
                    ...dashboardEnhancements,
                    multimodel: {
                        ...multimodel,
                        imageProxyUrl: `/api/weather/multimodel/image?allowStale=true&locationId=${encodeURIComponent(locationId)}`,
                        displayUpdatedAt: multimodel.imageFetchedAt ?? multimodel.lastSuccessAt,
                        sourceType: "official-relayed-image",
                        parity: "exact-image-relay",
                        statusLabel: multimodel.imageStatus === "unavailable" && !multimodel.imageUrlFound
                            ? "unavailable"
                            : multimodel.freshness === "fallback_error"
                                ? "fallback_error"
                                : multimodel.freshness === "revalidating"
                                    ? "revalidating"
                                    : "ready",
                    },
                };
            }, {
                shouldCache: hasFreshDashboardSync,
            });
        }
        case "GET /api/weather/multimodel/image": {
            const image = await service.getMultiModelImage(locationId, parseAllowStale(url.searchParams.get("allowStale")));
            const headers = new Headers(image.headers);
            headers.set("content-type", image.contentType);
            return new Response(new Uint8Array(image.body), {
                status: 200,
                headers,
            });
        }
        case "GET /api/weather/multimodel/status":
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.multimodelStatus, async () => await service.getMultiModelStatus(locationId), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/weather/multimodel/distribution":
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.multimodelDistribution, async () => await service.getMultiModelDistribution(locationId, parseTimestamp(url.searchParams.get("timestamp")), parseBucketSize(url.searchParams.get("bucketSize"))), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/weather/multimodel/insights":
            if (!service.getMultiModelInsight) {
                throw new AppError(503, "MULTIMODEL_INSIGHT_UNAVAILABLE", "Multimodel insights endpoint is not configured.", {
                    retryable: false,
                });
            }
            return await withEdgeJsonCache(request, ctx, EDGE_CACHE_TTL_SECONDS.multimodelInsight, async () => await service.getMultiModelInsight(locationId, parseTimestamp(url.searchParams.get("timestamp")), parseActualTemperatureC(url.searchParams.get("actualTemperatureC"))), {
                shouldCache: hasFreshFreshness,
            });
        case "GET /api/user/favorites":
            if (!service.getUserFavorites) {
                throw new AppError(503, "FAVORITES_UNAVAILABLE", "Favorites endpoint is not configured.", {
                    retryable: false,
                });
            }
            return jsonResponse(await service.getUserFavorites());
        default:
            break;
    }
    if (request.method === "PUT" && url.pathname.startsWith("/api/user/favorites/")) {
        if (!service.setUserFavorite) {
            throw new AppError(503, "FAVORITES_UNAVAILABLE", "Favorites endpoint is not configured.", {
                retryable: false,
            });
        }
        const locationPath = decodeURIComponent(url.pathname.slice("/api/user/favorites/".length));
        if (!locationPath) {
            throw new AppError(400, "BAD_REQUEST", "Path parameter 'locationId' must be a non-empty string.");
        }
        const favorite = parseFavoriteBody(await request.json());
        return jsonResponse(await service.setUserFavorite(locationPath, favorite));
    }
    throw new AppError(404, "NOT_FOUND", "Route not found.");
};
const isApiRequest = (pathname) => pathname === "/healthz" || pathname === "/metrics" || pathname.startsWith("/api/");
export default {
    async fetch(request, env, ctx) {
        const url = new URL(request.url);
        ensureRuntimeMetadata();
        try {
            if (url.pathname === "/api/weather/kelly/stream") {
                return await handleKellyStream(request, env, ctx);
            }
            if (isApiRequest(url.pathname)) {
                return await handleApiRequest(request, env, ctx);
            }
            return await env.ASSETS.fetch(request);
        }
        catch (error) {
            return handleError(error);
        }
    },
};
