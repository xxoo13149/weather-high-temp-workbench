const FAVORITES_KEY = "weather-high-temp-workbench:favorites";
const DEFAULT_RECORD = {
    locationIds: [],
    updatedAt: new Date(0).toISOString(),
};
const normalizeLocationIds = (values, allowedLocationIds) => {
    const unique = new Set();
    for (const value of values) {
        const id = value.trim();
        if (!id || !allowedLocationIds.has(id)) {
            continue;
        }
        unique.add(id);
    }
    return [...unique].sort((left, right) => left.localeCompare(right));
};
export class CloudflareFavoritesStore {
    kv;
    constructor(kv) {
        this.kv = kv;
    }
    async readRecord() {
        try {
            const raw = await this.kv.get(FAVORITES_KEY);
            if (!raw) {
                return DEFAULT_RECORD;
            }
            const parsed = JSON.parse(raw);
            return {
                locationIds: Array.isArray(parsed.locationIds)
                    ? parsed.locationIds.filter((item) => typeof item === "string")
                    : [],
                updatedAt: typeof parsed.updatedAt === "string" && parsed.updatedAt.length > 0
                    ? parsed.updatedAt
                    : DEFAULT_RECORD.updatedAt,
            };
        }
        catch {
            return DEFAULT_RECORD;
        }
    }
    async writeRecord(record) {
        await this.kv.put(FAVORITES_KEY, JSON.stringify(record));
    }
    async getFavorites(allowedLocationIds) {
        const record = await this.readRecord();
        const normalized = normalizeLocationIds(record.locationIds, allowedLocationIds);
        if (normalized.length !== record.locationIds.length) {
            const next = {
                locationIds: normalized,
                updatedAt: new Date().toISOString(),
            };
            await this.writeRecord(next);
            return next;
        }
        return {
            locationIds: normalized,
            updatedAt: record.updatedAt,
        };
    }
    async setFavorite(locationId, favorite, allowedLocationIds) {
        const current = await this.getFavorites(allowedLocationIds);
        const nextSet = new Set(current.locationIds);
        if (favorite) {
            nextSet.add(locationId);
        }
        else {
            nextSet.delete(locationId);
        }
        const next = {
            locationIds: normalizeLocationIds([...nextSet], allowedLocationIds),
            updatedAt: new Date().toISOString(),
        };
        await this.writeRecord(next);
        return next;
    }
}
export class InMemoryFavoritesStore {
    record = DEFAULT_RECORD;
    async getFavorites(allowedLocationIds) {
        const normalized = normalizeLocationIds(this.record.locationIds, allowedLocationIds);
        if (normalized.length !== this.record.locationIds.length) {
            this.record = {
                locationIds: normalized,
                updatedAt: new Date().toISOString(),
            };
        }
        return this.record;
    }
    async setFavorite(locationId, favorite, allowedLocationIds) {
        const current = await this.getFavorites(allowedLocationIds);
        const nextSet = new Set(current.locationIds);
        if (favorite) {
            nextSet.add(locationId);
        }
        else {
            nextSet.delete(locationId);
        }
        this.record = {
            locationIds: normalizeLocationIds([...nextSet], allowedLocationIds),
            updatedAt: new Date().toISOString(),
        };
        return this.record;
    }
}
