import { config, LOCATION_REGISTRY } from "../../config.js";
import { AppError } from "../../domain/errors.js";
import { buildDiscoveryWarnings, PolymarketClient } from "../../kelly/polymarket.js";
import { applyPricingToMarkets, buildKellyProbabilityContext, buildKellyWorkbench, buildReadableFramePoints, rebaseKellyMarketsForObservationFloor, buildStreamMarketPatches, resolveObservationFloor, resolveKellyDateKeyFromTimestamp, resolveKellyTargetDate, } from "../../kelly/workbench.js";
import { RefreshableCache } from "../../lib/cache.js";
import { FavoritesStore } from "../../lib/favorites-store.js";
import { fetchBinary, fetchText } from "../../lib/http.js";
import { fetchMetarSnapshot } from "../metar/service.js";
import { resolveLocation } from "./location-registry.js";
import { extractWeekMeteogramHighchartsUrl, parseWeekMeteogramHighcharts, resolveWeekMeteogramTemperatureUnit, } from "./meteogram.js";
import { buildMultiModelDistributionResponse, buildMultiModelInsightResponse, loadMultiModelDistribution, } from "./multimodel-distribution.js";
import { extractMultiModelImageUrl, MULTIMODEL_IMAGE_VERSION } from "./multimodel.js";
import { mergeHourlyItems, parseWeekPage, sanitizeHourlySummaryZh, sanitizeReportTextZh, WEEK_PARSER_VERSION, } from "./week.js";
const KELLY_STREAM_CLIENT_KEEPALIVE_MS = 20_000;
const KELLY_STREAM_POLLING_INTERVAL_MS = 30_000;
const KELLY_STREAM_REPRICE_DEBOUNCE_MS = 750;
const KELLY_STREAM_MODEL_CONTEXT_TTL_MS = 60_000;
const KELLY_STREAM_LAST_GOOD_TTL_MS = 120_000;
const KELLY_STREAM_REPRICE_FAILURE_WARN_THRESHOLD = 3;
const KELLY_STREAM_HUB_IDLE_TTL_MS = 90_000;
const METEOBLUE_WEEK_CACHE_LOAD_CONCURRENCY = 8;
const METEOBLUE_WEEK_PAGE_LOADER_TIMEOUT_MS = Math.min(config.httpTimeoutMs, 10_000);
const METEOBLUE_WEEK_METEOGRAM_LOADER_TIMEOUT_MS = Math.min(config.httpTimeoutMs, 10_000);
const METEOBLUE_WEEK_OPTIONAL_METEOGRAM_TIMEOUT_MS = Math.min(config.httpTimeoutMs, 2_500);
const METEOBLUE_MULTIMODEL_LOADER_TIMEOUT_MS = Math.min(config.httpTimeoutMs, 12_000);
const METEOBLUE_WEEK_CACHE_SLOT_TIMEOUT_MS = Math.max(config.httpTimeoutMs, 20_000);
const METEOBLUE_WEEK_PAGE_TOTAL_TIMEOUT_MS = METEOBLUE_WEEK_PAGE_LOADER_TIMEOUT_MS + 1_500;
const METEOBLUE_WEEK_METEOGRAM_TOTAL_TIMEOUT_MS = METEOBLUE_WEEK_METEOGRAM_LOADER_TIMEOUT_MS + 1_500;
const METEOBLUE_MULTIMODEL_TOTAL_TIMEOUT_MS = METEOBLUE_MULTIMODEL_LOADER_TIMEOUT_MS + 1_500;
const METEOBLUE_METAR_TOTAL_TIMEOUT_MS = Math.max(config.httpTimeoutMs, 10_000);
const POLYMARKET_DISCOVERY_TOTAL_TIMEOUT_MS = Math.max(config.httpTimeoutMs, 15_000);
const POLYMARKET_ORDERBOOK_TOTAL_TIMEOUT_MS = Math.max(config.httpTimeoutMs, 15_000);
const KELLY_WORKBENCH_TOTAL_TIMEOUT_MS = Math.max(POLYMARKET_DISCOVERY_TOTAL_TIMEOUT_MS + POLYMARKET_ORDERBOOK_TOTAL_TIMEOUT_MS, 30_000);
const createGlobalLimiter = (maxConcurrent, options) => {
    let active = 0;
    const waiters = [];
    return async (loader) => {
        if (active >= maxConcurrent) {
            await new Promise((resolve, reject) => {
                const waiter = {
                    released: false,
                    timerId: null,
                    resolve: () => {
                        if (waiter.released) {
                            return;
                        }
                        waiter.released = true;
                        if (waiter.timerId) {
                            clearTimeout(waiter.timerId);
                        }
                        resolve();
                    },
                };
                if (options?.waitTimeoutMs) {
                    waiter.timerId = setTimeout(() => {
                        if (waiter.released) {
                            return;
                        }
                        waiter.released = true;
                        const index = waiters.indexOf(waiter);
                        if (index >= 0) {
                            waiters.splice(index, 1);
                        }
                        reject(options.createTimeoutError?.() ??
                            new Error(`Timed out waiting for a cache load slot after ${options.waitTimeoutMs}ms.`));
                    }, options.waitTimeoutMs);
                }
                waiters.push(waiter);
            });
        }
        active += 1;
        try {
            return await loader();
        }
        finally {
            active = Math.max(0, active - 1);
            const next = waiters.shift();
            next?.resolve();
        }
    };
};
const withWeekCacheLoadSlot = createGlobalLimiter(METEOBLUE_WEEK_CACHE_LOAD_CONCURRENCY, {
    waitTimeoutMs: METEOBLUE_WEEK_CACHE_SLOT_TIMEOUT_MS,
    createTimeoutError: () => new AppError(503, "WEEK_CACHE_LOAD_BUSY", `Week cache load queue exceeded ${METEOBLUE_WEEK_CACHE_SLOT_TIMEOUT_MS}ms.`, {
        retryable: true,
    }),
});
const createWeekPageLoaderSignal = () => AbortSignal.timeout(METEOBLUE_WEEK_PAGE_LOADER_TIMEOUT_MS);
const createWeekMeteogramLoaderSignal = () => AbortSignal.timeout(METEOBLUE_WEEK_METEOGRAM_LOADER_TIMEOUT_MS);
const createOptionalWeekMeteogramLoaderSignal = () => AbortSignal.timeout(METEOBLUE_WEEK_OPTIONAL_METEOGRAM_TIMEOUT_MS);
const createMultiModelLoaderSignal = () => AbortSignal.timeout(METEOBLUE_MULTIMODEL_LOADER_TIMEOUT_MS);
const withTimeout = async (promise, timeoutMs, createError) => {
    let timerId = null;
    try {
        return await Promise.race([
            promise,
            new Promise((_, reject) => {
                timerId = setTimeout(() => reject(createError()), timeoutMs);
            }),
        ]);
    }
    finally {
        if (timerId) {
            clearTimeout(timerId);
        }
    }
};
const INITIAL_KELLY_STAGE_TIMINGS = {
    hourly: null,
    report: null,
    metar: null,
    insight: null,
    distribution: null,
    marketDiscovery: null,
    orderbook: null,
    pricing: null,
    total: null,
};
const cloneKellyStageTimings = (value) => ({
    ...INITIAL_KELLY_STAGE_TIMINGS,
    ...(value ?? {}),
});
const measureAsync = async (stageTimings, key, loader) => {
    const startedAt = Date.now();
    try {
        return await loader();
    }
    finally {
        stageTimings[key] = Date.now() - startedAt;
    }
};
const buildKellyCacheKey = (locationId, targetDate) => `${locationId}::${targetDate}`;
const buildKellySnapshotRequestKey = (locationId, targetDate, options) => [
    locationId,
    targetDate,
    options.bankroll ?? "default-bankroll",
    options.riskMode ?? "default-risk",
    options.minEdge ?? "default-edge",
    options.actualTemperatureC ?? "default-temp",
    options.selectedHourTimestamp ?? "default-hour",
].join("::");
const KELLY_SNAPSHOT_RESULT_TTL_MS = 5_000;
const resolveMetarObservedHighFloor = (recentTemperatures, targetDate, timeZone) => {
    const formatter = new Intl.DateTimeFormat("en-CA", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    });
    const sameDaySamples = recentTemperatures.filter((sample) => formatter.format(new Date(sample.observedAt)) === targetDate);
    if (sameDaySamples.length === 0) {
        return null;
    }
    const best = [...sameDaySamples].sort((left, right) => right.temperatureC - left.temperatureC || right.observedAt.localeCompare(left.observedAt))[0];
    if (!best) {
        return null;
    }
    return {
        value: best.temperatureC,
        source: "metar",
        observedAt: best.observedAt,
    };
};
const resolveKellyDistributionTimestamp = (availableTimestamps, targetDate, timeZone) => {
    const matching = availableTimestamps.filter((timestamp) => resolveKellyDateKeyFromTimestamp(timestamp, timeZone) === targetDate);
    if (matching.length === 0) {
        return null;
    }
    return matching[Math.floor(matching.length / 2)] ?? matching[0] ?? null;
};
const parseIsoDateKeyUtcMs = (value) => {
    const [year, month, day] = value.split("-").map((entry) => Number.parseInt(entry, 10));
    if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day)) {
        return null;
    }
    return Date.UTC(year, month - 1, day);
};
const resolveKellyDistributionSelection = (availableTimestamps, targetDate, timeZone) => {
    const grouped = new Map();
    for (const timestamp of availableTimestamps) {
        const dateKey = resolveKellyDateKeyFromTimestamp(timestamp, timeZone);
        if (!dateKey) {
            continue;
        }
        const list = grouped.get(dateKey) ?? [];
        list.push(timestamp);
        grouped.set(dateKey, list);
    }
    const availableTargetDates = [...grouped.keys()].sort();
    if (availableTargetDates.length === 0) {
        return {
            timestamp: null,
            effectiveTargetDate: targetDate,
            requestedTargetDate: targetDate,
            usedFallback: false,
            availableTargetDates: [],
        };
    }
    let effectiveTargetDate = targetDate;
    if (!grouped.has(effectiveTargetDate)) {
        const requestedUtcMs = parseIsoDateKeyUtcMs(targetDate);
        if (requestedUtcMs === null) {
            effectiveTargetDate = availableTargetDates[availableTargetDates.length - 1] ?? availableTargetDates[0];
        }
        else {
            const availableBeforeOrEqual = availableTargetDates
                .map((dateKey) => ({
                dateKey,
                utcMs: parseIsoDateKeyUtcMs(dateKey),
            }))
                .filter((entry) => entry.utcMs !== null)
                .filter((entry) => entry.utcMs <= requestedUtcMs)
                .sort((left, right) => right.utcMs - left.utcMs);
            if (availableBeforeOrEqual.length > 0) {
                effectiveTargetDate = availableBeforeOrEqual[0].dateKey;
            }
            else {
                effectiveTargetDate = availableTargetDates[0];
            }
        }
    }
    const effectiveTimestamps = grouped.get(effectiveTargetDate) ?? [];
    const timestamp = effectiveTimestamps[Math.floor(effectiveTimestamps.length / 2)] ??
        effectiveTimestamps[0] ??
        null;
    return {
        timestamp,
        effectiveTargetDate,
        requestedTargetDate: targetDate,
        usedFallback: effectiveTargetDate !== targetDate,
        availableTargetDates,
    };
};
const normalizeText = (value) => value.replace(/\s+/g, " ").trim();
const hasDiscoveryCandidates = (value) => Boolean(value) && (value.candidates.length > 0 || value.inactiveCandidates.length > 0);
const dateFormatterCache = new Map();
const getDateFormatter = (timeZone) => {
    const cached = dateFormatterCache.get(timeZone);
    if (cached) {
        return cached;
    }
    const formatter = new Intl.DateTimeFormat("en-CA", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    });
    dateFormatterCache.set(timeZone, formatter);
    return formatter;
};
const localDateKey = (timestamp, timeZone) => {
    const parsed = new Date(timestamp);
    if (Number.isNaN(parsed.getTime())) {
        return null;
    }
    return getDateFormatter(timeZone).format(parsed);
};
const nearestItemIndex = (items, nowMs) => {
    let nearestIndex = -1;
    let nearestDistance = Number.POSITIVE_INFINITY;
    for (let index = 0; index < items.length; index += 1) {
        const item = items[index];
        if (!item?.timestamp) {
            continue;
        }
        const itemMs = Date.parse(item.timestamp);
        if (Number.isNaN(itemMs)) {
            continue;
        }
        const distance = Math.abs(itemMs - nowMs);
        if (distance < nearestDistance) {
            nearestDistance = distance;
            nearestIndex = index;
        }
    }
    return nearestIndex;
};
const sanitizeHourlyItems = (items) => items.map((item) => ({
    ...item,
    summaryZh: sanitizeHourlySummaryZh(item.summaryZh, item.summary),
}));
const coverageFields = ["precipitationProbabilityPct", "feelsLikeC", "windDirection"];
const meteogramSupportedCoverageFields = new Set(["windDirection"]);
const createMissingReasonCounter = () => ({
    "source-unpublished": 0,
    "parser-unrecognized": 0,
    "fallback-unavailable": 0,
});
const resolveCompleteness = (availableHours, totalHours) => {
    if (availableHours <= 0 || totalHours <= 0) {
        return "missing";
    }
    if (availableHours >= totalHours) {
        return "full";
    }
    return "partial";
};
const buildFieldCoverage = ({ items, sourceType, preferredItems, fallbackItems, fieldDiagnostics, }) => {
    const preferredByTimestamp = new Map((preferredItems ?? items).map((item) => [item.timestamp, item]));
    const fallbackByTimestamp = new Map((fallbackItems ?? []).map((item) => [item.timestamp, item]));
    const mixedSourceSet = new Set();
    for (const item of items) {
        if (preferredByTimestamp.has(item.timestamp)) {
            mixedSourceSet.add(sourceType);
        }
        if (fallbackByTimestamp.has(item.timestamp)) {
            mixedSourceSet.add("week-meteogram-highcharts");
        }
    }
    if (mixedSourceSet.size === 0) {
        mixedSourceSet.add(sourceType);
    }
    const entries = Object.fromEntries(coverageFields.map((field) => {
        let availableHours = 0;
        let preferredHits = 0;
        let fallbackHits = 0;
        const missingReasons = createMissingReasonCounter();
        for (const item of items) {
            const preferred = preferredByTimestamp.get(item.timestamp);
            const fallback = fallbackByTimestamp.get(item.timestamp);
            const currentValue = item[field];
            const preferredValue = preferred?.[field] ?? null;
            const fallbackValue = fallback?.[field] ?? null;
            if (currentValue !== null) {
                availableHours += 1;
                if (preferredValue !== null) {
                    preferredHits += 1;
                }
                else if (fallbackValue !== null) {
                    fallbackHits += 1;
                }
                else if (!preferred && fallback) {
                    fallbackHits += 1;
                }
                else {
                    preferredHits += 1;
                }
                continue;
            }
            let reason = "parser-unrecognized";
            if (preferred) {
                reason = fieldDiagnostics?.[field].missingByTimestamp[item.timestamp] ?? "source-unpublished";
            }
            else if (fallback) {
                reason = meteogramSupportedCoverageFields.has(field) ? "source-unpublished" : "fallback-unavailable";
            }
            else if (sourceType === "week-meteogram-highcharts" && !meteogramSupportedCoverageFields.has(field)) {
                reason = "fallback-unavailable";
            }
            missingReasons[reason] += 1;
        }
        const totalHours = items.length;
        const source = preferredHits > 0 && fallbackHits > 0
            ? "mixed"
            : preferredHits > 0
                ? sourceType
                : fallbackHits > 0
                    ? "week-meteogram-highcharts"
                    : sourceType === "week-meteogram-highcharts" && !meteogramSupportedCoverageFields.has(field)
                        ? "mixed"
                        : sourceType;
        return [
            field,
            {
                availableHours,
                totalHours,
                source,
                completeness: resolveCompleteness(availableHours, totalHours),
                missingReasons,
            },
        ];
    }));
    return {
        precipitationProbabilityPct: entries.precipitationProbabilityPct,
        feelsLikeC: entries.feelsLikeC,
        windDirection: entries.windDirection,
        mixedSources: [...mixedSourceSet],
    };
};
const isFallbackErrorFreshness = (freshness) => freshness === "fallback_error";
const isRevalidatingFreshness = (freshness) => freshness === "revalidating";
const resolveSnapshotFreshness = (snapshot) => snapshot.freshness ??
    (snapshot.entry
        ? snapshot.lastError
            ? "fallback_error"
            : snapshot.inFlight
                ? "revalidating"
                : "fresh"
        : null);
const ensureCacheHasEntry = async (cache) => {
    if (cache.peek().entry === null) {
        try {
            await cache.get({ allowStaleOnError: true });
        }
        catch {
            // ignore loader failures; status will reflect last known state
        }
    }
};
const resolveLatestOrderbookTimestamp = (books) => [...books.values()].sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))[0]?.updatedAt ?? null;
export class MeteoblueWeatherService {
    weekCaches = new Map();
    multiModelImageCaches = new Map();
    multiModelDistributionCaches = new Map();
    metarCaches = new Map();
    kellyMarketCaches = new Map();
    kellyOrderBookCaches = new Map();
    kellyOrderBookRefreshInFlight = new Map();
    kellyFrameHistories = new Map();
    kellyObservationFloors = new Map();
    favoritesStore;
    allowedLocationIds;
    polymarketClient;
    kellySnapshotInFlight = new Map();
    kellySnapshotResults = new Map();
    kellyStreamModelContexts = new Map();
    kellyStreamLastGoodSnapshots = new Map();
    kellyStreamRepriceInFlight = new Map();
    kellyStreamHubs = new Map();
    kellyStreamSubscriberSequence = 0;
    kellyRuntimeHealth = {
        service: "kelly-origin",
        lastSnapshotSuccessAt: null,
        lastSnapshotErrorAt: null,
        lastSnapshotError: null,
        lastMarketDiscoveryAt: null,
        lastOrderbookAt: null,
        lastRepricedAt: null,
        lastSignalAt: null,
        lastStreamEventAt: null,
        openStreamCount: 0,
        activeHubCount: 0,
        fallbackMode: false,
        lastStageTimingsMs: cloneKellyStageTimings(),
    };
    constructor(options) {
        this.favoritesStore = options?.favoritesStore ?? new FavoritesStore();
        this.allowedLocationIds = new Set(Object.keys(LOCATION_REGISTRY));
        this.polymarketClient = new PolymarketClient();
    }
    readKellyStreamModelContext(cacheKey) {
        const cached = this.kellyStreamModelContexts.get(cacheKey);
        if (!cached) {
            return null;
        }
        if (cached.expiresAt <= Date.now()) {
            this.kellyStreamModelContexts.delete(cacheKey);
            return null;
        }
        return cached;
    }
    writeKellyStreamModelContext(cacheKey, probabilityCurve, shrink) {
        this.kellyStreamModelContexts.set(cacheKey, {
            expiresAt: Date.now() + KELLY_STREAM_MODEL_CONTEXT_TTL_MS,
            probabilityCurve,
            shrink,
        });
    }
    readKellyStreamLastGoodSnapshot(cacheKey) {
        const cached = this.kellyStreamLastGoodSnapshots.get(cacheKey);
        if (!cached) {
            return null;
        }
        if (cached.expiresAt <= Date.now()) {
            this.kellyStreamLastGoodSnapshots.delete(cacheKey);
            return null;
        }
        return cached;
    }
    writeKellyStreamLastGoodSnapshot(cacheKey, payload) {
        this.kellyStreamLastGoodSnapshots.set(cacheKey, {
            expiresAt: Date.now() + KELLY_STREAM_LAST_GOOD_TTL_MS,
            generatedAt: payload.generatedAt,
            repricedAt: payload.repricedAt,
            repricedMarkets: payload.repricedMarkets,
            framePoints: payload.framePoints,
        });
    }
    readKellySnapshotResult(cacheKey, options) {
        const cached = this.kellySnapshotResults.get(cacheKey);
        if (!cached) {
            return null;
        }
        if (cached.expiresAt > Date.now() || options?.includeExpired) {
            return cached.snapshot;
        }
        this.kellySnapshotResults.delete(cacheKey);
        return null;
    }
    buildKellyFallbackSnapshotFromCache(snapshot, reason) {
        const detail = reason instanceof AppError ? `${reason.code}: ${reason.message}` : reason instanceof Error ? reason.message : String(reason);
        const warning = `本轮 Kelly 刷新超时或失败，当前继续沿用上一轮可用快照。${detail ? `(${detail})` : ""}`;
        return {
            ...snapshot,
            warnings: snapshot.warnings.includes(warning) ? snapshot.warnings : [...snapshot.warnings, warning],
        };
    }
    recordKellySnapshotSuccess(details) {
        this.kellyRuntimeHealth.lastSnapshotSuccessAt = details.generatedAt;
        this.kellyRuntimeHealth.lastSnapshotErrorAt = null;
        this.kellyRuntimeHealth.lastSnapshotError = null;
        this.kellyRuntimeHealth.lastMarketDiscoveryAt = details.discoveryFetchedAt ?? this.kellyRuntimeHealth.lastMarketDiscoveryAt;
        this.kellyRuntimeHealth.lastOrderbookAt = details.orderbookFetchedAt ?? this.kellyRuntimeHealth.lastOrderbookAt;
        this.kellyRuntimeHealth.lastRepricedAt = details.repricedAt ?? this.kellyRuntimeHealth.lastRepricedAt;
        this.kellyRuntimeHealth.lastStageTimingsMs = cloneKellyStageTimings(details.stageTimings);
    }
    recordKellySnapshotFailure(error, stageTimings) {
        this.kellyRuntimeHealth.lastSnapshotErrorAt = new Date().toISOString();
        this.kellyRuntimeHealth.lastSnapshotError = error instanceof Error ? error.message : String(error);
        this.kellyRuntimeHealth.lastStageTimingsMs = cloneKellyStageTimings(stageTimings);
    }
    recordKellyStreamEvent(generatedAt, fallbackMode) {
        this.kellyRuntimeHealth.lastStreamEventAt = generatedAt;
        if (typeof fallbackMode === "boolean") {
            this.kellyRuntimeHealth.fallbackMode = fallbackMode;
        }
    }
    recordKellySignal(occurredAt) {
        this.kellyRuntimeHealth.lastSignalAt = occurredAt;
    }
    syncKellyHubCount() {
        this.kellyRuntimeHealth.activeHubCount = this.kellyStreamHubs.size;
    }
    syncKellyFallbackMode() {
        this.kellyRuntimeHealth.fallbackMode = [...this.kellyStreamHubs.values()].some((hub) => Boolean(hub.fallbackTimer));
    }
    getKellyRuntimeHealth() {
        return {
            ...this.kellyRuntimeHealth,
            lastStageTimingsMs: cloneKellyStageTimings(this.kellyRuntimeHealth.lastStageTimingsMs),
            activeHubCount: this.kellyStreamHubs.size,
        };
    }
    invalidateKellySnapshotResults(locationId, targetDate) {
        const prefix = `${locationId}::${targetDate}::`;
        for (const key of this.kellySnapshotResults.keys()) {
            if (key.startsWith(prefix)) {
                this.kellySnapshotResults.delete(key);
            }
        }
    }
    requireLocation(locationId) {
        if (!this.allowedLocationIds.has(locationId)) {
            throw new AppError(400, "BAD_REQUEST", `Unknown locationId '${locationId}'.`);
        }
        return resolveLocation(locationId);
    }
    getWeekCache(locationId) {
        const existing = this.weekCaches.get(locationId);
        if (existing) {
            return existing;
        }
        const location = this.requireLocation(locationId);
        const cache = new RefreshableCache(config.weekPageTtlMs, async () => withWeekCacheLoadSlot(async () => {
            const weekPageSignal = createWeekPageLoaderSignal();
            const html = await withTimeout(fetchText(location.weekPageUrl, { signal: weekPageSignal }), METEOBLUE_WEEK_PAGE_TOTAL_TIMEOUT_MS, () => new AppError(504, "WEEK_PAGE_TIMEOUT", `Meteoblue week page fetch exceeded ${METEOBLUE_WEEK_PAGE_TOTAL_TIMEOUT_MS}ms.`, {
                retryable: true,
            }));
            const fetchedAt = new Date();
            const parsed = parseWeekPage(html, fetchedAt, location.timezone, location.name, location.fallbackDisplayUnit);
            const hasOneHourTable = parsed.oneHourItems.length > 0;
            const oneHourWarnings = [...parsed.oneHourWarnings];
            let meteogramRaw = "";
            let meteogramItems = [];
            try {
                const meteogramHighchartsUrl = extractWeekMeteogramHighchartsUrl(html);
                const meteogramTemperatureUnit = resolveWeekMeteogramTemperatureUnit(meteogramHighchartsUrl, location.fallbackDisplayUnit);
                const meteogramSignal = hasOneHourTable
                    ? createOptionalWeekMeteogramLoaderSignal()
                    : createWeekMeteogramLoaderSignal();
                const meteogramTimeoutMs = hasOneHourTable
                    ? METEOBLUE_WEEK_OPTIONAL_METEOGRAM_TIMEOUT_MS + 1_000
                    : METEOBLUE_WEEK_METEOGRAM_TOTAL_TIMEOUT_MS;
                meteogramRaw = await withTimeout(fetchText(meteogramHighchartsUrl, { signal: meteogramSignal }), meteogramTimeoutMs, () => new AppError(504, "WEEK_METEOGRAM_TIMEOUT", `Meteoblue week meteogram fetch exceeded ${meteogramTimeoutMs}ms.`, {
                    retryable: true,
                }));
                const meteogram = parseWeekMeteogramHighcharts(meteogramRaw, location.timezone, meteogramTemperatureUnit);
                meteogramItems = meteogram.items;
            }
            catch (error) {
                if (!hasOneHourTable) {
                    throw error;
                }
                const detail = error instanceof Error ? error.message : String(error);
                oneHourWarnings.push(`Embedded meteogram enrichment unavailable; using parsed week table data only. ${detail}`.trim());
            }
            const mergedOneHourItems = mergeHourlyItems(parsed.oneHourItems, meteogramItems);
            if (!hasOneHourTable) {
                oneHourWarnings.push("1h data fell back to embedded meteogram because the 1h table could not be parsed.");
            }
            return {
                fetchedAt: fetchedAt.toISOString(),
                sourceObservedAt: parsed.sourceObservedAt,
                weekPageHtml: html,
                weekTable1h: parsed.oneHourItems,
                weekTable3h: parsed.threeHourItems,
                weekMeteogramHighchartsRawJson: meteogramRaw,
                weekMeteogramHighcharts: meteogramItems,
                weatherReportRaw: parsed.report,
                hourly: {
                    "1h": {
                        items: hasOneHourTable ? mergedOneHourItems : meteogramItems,
                        sourceType: hasOneHourTable ? "week-table-1h" : "week-meteogram-highcharts",
                        warnings: oneHourWarnings,
                        partial: hasOneHourTable ? parsed.oneHourPartial : true,
                        preferredItems: parsed.oneHourItems,
                        fallbackItems: meteogramItems,
                        fieldDiagnostics: parsed.oneHourFieldDiagnostics,
                    },
                    "3h": {
                        items: parsed.threeHourItems,
                        sourceType: "week-table-3h",
                        warnings: parsed.warnings,
                        partial: parsed.partial,
                        preferredItems: parsed.threeHourItems,
                        fieldDiagnostics: null,
                    },
                },
                report: {
                    location: {
                        id: location.id,
                        name: location.name,
                        timezone: location.timezone,
                    },
                    pageUrl: location.weekPageUrl,
                    parserVersion: WEEK_PARSER_VERSION,
                    available: parsed.report.available,
                    titleEn: parsed.report.titleEn,
                    sourceTextEn: parsed.report.sourceTextEn,
                    textZh: parsed.report.textZh,
                    metrics: parsed.report.metrics,
                    warnings: parsed.report.warnings,
                },
            };
        }));
        this.weekCaches.set(locationId, cache);
        return cache;
    }
    getMultiModelImageCache(locationId) {
        const existing = this.multiModelImageCaches.get(locationId);
        if (existing) {
            return existing;
        }
        const location = this.requireLocation(locationId);
        const cache = new RefreshableCache(config.multimodelImageTtlMs, async () => {
            const pageHtml = await withTimeout(fetchText(location.multimodelPageUrl, { signal: createMultiModelLoaderSignal() }), METEOBLUE_MULTIMODEL_TOTAL_TIMEOUT_MS, () => new AppError(504, "MULTIMODEL_PAGE_TIMEOUT", `Meteoblue multimodel page fetch exceeded ${METEOBLUE_MULTIMODEL_TOTAL_TIMEOUT_MS}ms.`, {
                retryable: true,
            }));
            const pageFetchedAt = new Date().toISOString();
            const imageUrl = extractMultiModelImageUrl(pageHtml);
            const image = await withTimeout(fetchBinary(imageUrl, { signal: createMultiModelLoaderSignal() }), METEOBLUE_MULTIMODEL_TOTAL_TIMEOUT_MS, () => new AppError(504, "MULTIMODEL_IMAGE_TIMEOUT", `Meteoblue multimodel image fetch exceeded ${METEOBLUE_MULTIMODEL_TOTAL_TIMEOUT_MS}ms.`, {
                retryable: true,
            }));
            if (!image.contentType.toLowerCase().includes("image/png")) {
                throw new AppError(503, "MULTIMODEL_IMAGE_INVALID_CONTENT_TYPE", `Expected image/png content-type, got ${image.contentType}.`, {
                    retryable: true,
                });
            }
            return {
                pageFetchedAt,
                imageFetchedAt: new Date().toISOString(),
                imageUrl,
                contentType: image.contentType,
                body: image.body,
            };
        });
        this.multiModelImageCaches.set(locationId, cache);
        return cache;
    }
    getMultiModelDistributionCache(locationId) {
        const existing = this.multiModelDistributionCaches.get(locationId);
        if (existing) {
            return existing;
        }
        const location = this.requireLocation(locationId);
        const cache = new RefreshableCache(config.multimodelDistributionTtlMs, async () => await withTimeout(loadMultiModelDistribution(location.multimodelPageUrl, location.timezone, createMultiModelLoaderSignal(), location.fallbackDisplayUnit), METEOBLUE_MULTIMODEL_TOTAL_TIMEOUT_MS, () => new AppError(504, "MULTIMODEL_LOAD_TIMEOUT", `Meteoblue multimodel data fetch exceeded ${METEOBLUE_MULTIMODEL_TOTAL_TIMEOUT_MS}ms.`, {
            retryable: true,
        })));
        this.multiModelDistributionCaches.set(locationId, cache);
        return cache;
    }
    getMetarCache(locationId) {
        const existing = this.metarCaches.get(locationId);
        if (existing) {
            return existing;
        }
        const location = this.requireLocation(locationId);
        const cache = new RefreshableCache(60_000, async () => await withTimeout(fetchMetarSnapshot({
            id: location.id,
            name: location.name,
            timezone: location.timezone,
        }), METEOBLUE_METAR_TOTAL_TIMEOUT_MS, () => new AppError(504, "METAR_TIMEOUT", `METAR fetch exceeded ${METEOBLUE_METAR_TOTAL_TIMEOUT_MS}ms.`, {
            retryable: true,
        })));
        this.metarCaches.set(locationId, cache);
        return cache;
    }
    getKellyMarketCache(locationId, targetDate) {
        const key = buildKellyCacheKey(locationId, targetDate);
        const existing = this.kellyMarketCaches.get(key);
        if (existing) {
            return existing;
        }
        const location = this.requireLocation(locationId);
        let cache = null;
        cache = new RefreshableCache(config.polymarketMarketTtlMs, async () => {
            const discoveryResult = await withTimeout(this.polymarketClient.discoverMarkets(location, targetDate), POLYMARKET_DISCOVERY_TOTAL_TIMEOUT_MS, () => new AppError(503, "POLYMARKET_DISCOVERY_TIMEOUT", `Polymarket discovery exceeded ${POLYMARKET_DISCOVERY_TOTAL_TIMEOUT_MS}ms.`, {
                retryable: true,
            }));
            const previousDiscovery = cache?.peek().entry?.value ?? null;
            if (!hasDiscoveryCandidates(discoveryResult) && hasDiscoveryCandidates(previousDiscovery)) {
                throw new AppError(503, "POLYMARKET_DISCOVERY_EMPTY_REFRESH", "Polymarket discovery refresh returned no candidates; preserving the previous snapshot.", {
                    retryable: true,
                });
            }
            return discoveryResult;
        });
        this.kellyMarketCaches.set(key, cache);
        return cache;
    }
    getKellyOrderBookCache(locationId, targetDate) {
        const key = buildKellyCacheKey(locationId, targetDate);
        const existing = this.kellyOrderBookCaches.get(key);
        if (existing) {
            return existing;
        }
        let cache = null;
        cache = new RefreshableCache(config.polymarketOrderbookTtlMs, async () => {
            const marketResult = await this.getKellyMarketCache(locationId, targetDate).get({ allowStaleOnError: true });
            const tokenIds = marketResult.value.candidates
                .filter((candidate) => candidate.parseStatus === "matched")
                .flatMap((candidate) => [candidate.yesTokenId, candidate.noTokenId])
                .filter((tokenId) => Boolean(tokenId));
            if (!tokenIds.length) {
                return new Map();
            }
            const freshBooks = await this.fetchFreshKellyOrderBooks(locationId, targetDate, tokenIds);
            const previousBooks = cache?.peek().entry?.value ?? null;
            return this.mergeKellyOrderBooks(tokenIds, freshBooks, previousBooks);
        });
        this.kellyOrderBookCaches.set(key, cache);
        return cache;
    }
    async fetchFreshKellyOrderBooks(locationId, targetDate, tokenIds) {
        const key = buildKellyCacheKey(locationId, targetDate);
        const existing = this.kellyOrderBookRefreshInFlight.get(key);
        if (existing) {
            return await existing;
        }
        const task = withTimeout(this.polymarketClient.fetchOrderBooks(tokenIds), POLYMARKET_ORDERBOOK_TOTAL_TIMEOUT_MS, () => new AppError(503, "POLYMARKET_ORDERBOOK_TIMEOUT", `Polymarket orderbook fetch exceeded ${POLYMARKET_ORDERBOOK_TOTAL_TIMEOUT_MS}ms.`, {
            retryable: true,
        }));
        this.kellyOrderBookRefreshInFlight.set(key, task);
        try {
            return await task;
        }
        finally {
            if (this.kellyOrderBookRefreshInFlight.get(key) === task) {
                this.kellyOrderBookRefreshInFlight.delete(key);
            }
        }
    }
    mergeKellyOrderBooks(tokenIds, freshBooks, previousBooks) {
        if (!previousBooks || previousBooks.size === 0) {
            return freshBooks;
        }
        const mergedBooks = new Map(freshBooks);
        for (const tokenId of new Set(tokenIds.filter(Boolean))) {
            if (mergedBooks.has(tokenId)) {
                continue;
            }
            const previousBook = previousBooks.get(tokenId);
            if (previousBook) {
                mergedBooks.set(tokenId, previousBook);
            }
        }
        return mergedBooks;
    }
    resolveKellyObservationFloor(location, targetDate, hourly, metarObservation, recentMetarTemperatures, options) {
        const today = resolveKellyTargetDate(location.timezone);
        const cacheKey = buildKellyCacheKey(location.id, targetDate);
        const rememberedFloor = targetDate === today ? this.kellyObservationFloors.get(cacheKey) ?? null : null;
        const observedMetarHigh = resolveMetarObservedHighFloor(recentMetarTemperatures, targetDate, location.timezone);
        const floor = resolveObservationFloor(hourly, metarObservation, options, {
            targetDate,
            timeZone: location.timezone,
            rememberedFloor,
            observedMetarHigh,
        });
        if (targetDate === today && typeof floor.value === "number" && Number.isFinite(floor.value)) {
            this.kellyObservationFloors.set(cacheKey, {
                value: floor.value,
                source: floor.source,
                observedAt: floor.observedAt,
            });
        }
        return floor;
    }
    rememberKellyFrameHistory(locationId, targetDate, nextFrames, generatedAt) {
        const key = buildKellyCacheKey(locationId, targetDate);
        const existing = this.kellyFrameHistories.get(key) ?? [];
        const merged = new Map();
        for (const frame of existing) {
            merged.set(frame.id, frame);
        }
        for (const frame of nextFrames) {
            merged.set(frame.id, frame);
        }
        const cutoffMs = Date.parse(generatedAt) - 60 * 60 * 1000;
        const history = [...merged.values()]
            .filter((frame) => {
            const frameTime = Date.parse(frame.generatedAt);
            return Number.isNaN(frameTime) || frameTime >= cutoffMs;
        })
            .sort((left, right) => left.generatedAt.localeCompare(right.generatedAt));
        this.kellyFrameHistories.set(key, history);
        return history;
    }
    async repriceKellyStreamSnapshot({ locationId, location, targetDate, options, matchedMarkets, trackedMarkets, bankroll, riskMode, minEdge, probabilityCurve, shrink, booksOverride, generatedAtOverride, orderbookObservedAtOverride, }) {
        const streamKey = buildKellySnapshotRequestKey(locationId, targetDate, {
            ...options,
            bankroll,
            riskMode,
            minEdge,
        });
        const existing = this.kellyStreamRepriceInFlight.get(streamKey);
        if (existing) {
            return await existing;
        }
        const task = (async () => {
            const tokenIds = matchedMarkets.flatMap((market) => [market.yesTokenId, market.noTokenId]);
            const orderBookCache = this.getKellyOrderBookCache(locationId, targetDate);
            const cachedBooks = booksOverride ?? orderBookCache.peek().entry?.value ?? null;
            const [hourly, metarResult] = await Promise.all([
                this.getHourly(locationId, "1h"),
                this.getMetarCache(locationId).get({ allowStaleOnError: true }),
            ]);
            let books;
            if (booksOverride) {
                books = booksOverride;
            }
            else {
                const freshBooks = await this.fetchFreshKellyOrderBooks(locationId, targetDate, tokenIds);
                if (freshBooks.size === 0 && cachedBooks && cachedBooks.size > 0) {
                    throw new AppError(503, "POLYMARKET_ORDERBOOK_REFRESH_EMPTY", "Polymarket orderbook refresh returned no fresh books.", {
                        retryable: true,
                    });
                }
                books = this.mergeKellyOrderBooks(tokenIds, freshBooks, cachedBooks);
            }
            const generatedAt = generatedAtOverride ?? new Date().toISOString();
            const orderbookObservedAt = orderbookObservedAtOverride ?? resolveLatestOrderbookTimestamp(books);
            const repricedAt = generatedAt;
            if (!booksOverride) {
                orderBookCache.set(books, new Date(generatedAt));
            }
            this.invalidateKellySnapshotResults(locationId, targetDate);
            const metarObservation = metarResult.value.observation
                ? {
                    ...metarResult.value.observation,
                    stale: metarResult.stale,
                    freshness: metarResult.freshness,
                    cacheHit: metarResult.cacheHit,
                }
                : null;
            const observationFloor = this.resolveKellyObservationFloor(location, targetDate, hourly, metarObservation, metarResult.value.recentTemperatures, options);
            let nextProbabilityCurve = probabilityCurve;
            let nextShrink = shrink;
            const cachedModelContext = this.readKellyStreamModelContext(streamKey);
            if (cachedModelContext) {
                nextProbabilityCurve = cachedModelContext.probabilityCurve;
                nextShrink = cachedModelContext.shrink;
            }
            else {
                try {
                    const resolvedActualTemperatureForInsight = options.actualTemperatureC ??
                        metarObservation?.temperatureC ??
                        hourly.current?.temperatureC ??
                        undefined;
                    const insight = await this.getMultiModelInsight(locationId, options.selectedHourTimestamp, resolvedActualTemperatureForInsight);
                    const targetDistributionTimestamp = resolveKellyDistributionTimestamp(insight.availableTimestamps, targetDate, location.timezone);
                    if (targetDistributionTimestamp) {
                        const distribution = await this.getMultiModelDistribution(locationId, targetDistributionTimestamp, 1);
                        const probabilityContext = buildKellyProbabilityContext({
                            hourly,
                            insight,
                            distribution,
                            metarObservation,
                            options,
                            targetDate,
                            timeZone: location.timezone,
                            observationFloorOverride: observationFloor,
                        });
                        nextProbabilityCurve = probabilityContext.curve;
                        nextShrink = probabilityContext.shrink;
                        this.writeKellyStreamModelContext(streamKey, nextProbabilityCurve, nextShrink);
                    }
                }
                catch {
                    // Keep live repricing available even if the auxiliary model context
                    // cannot be refreshed for this tick. The latest observation floor still
                    // applies against the last committed probability baseline.
                }
            }
            const rebasedMarkets = rebaseKellyMarketsForObservationFloor(trackedMarkets, nextProbabilityCurve, nextShrink, observationFloor.value);
            const repricedMarkets = applyPricingToMarkets(rebasedMarkets, books, {
                bankroll,
                riskMode,
                minEdge,
            });
            const framePoints = buildReadableFramePoints(repricedMarkets, generatedAt);
            this.rememberKellyFrameHistory(locationId, targetDate, framePoints, generatedAt);
            return {
                books,
                framePoints,
                generatedAt,
                orderbookObservedAt,
                repricedAt,
                repricedMarkets,
            };
        })();
        this.kellyStreamRepriceInFlight.set(streamKey, task);
        try {
            return await task;
        }
        finally {
            if (this.kellyStreamRepriceInFlight.get(streamKey) === task) {
                this.kellyStreamRepriceInFlight.delete(streamKey);
            }
        }
    }
    async getHourly(locationId, mode, limit) {
        const location = this.requireLocation(locationId);
        const result = await this.getWeekCache(locationId).get({
            allowStaleOnError: true,
            staleWhileRevalidate: true,
        });
        const hourly = result.value.hourly[mode];
        const maxItems = typeof limit === "number" && limit > 0 ? limit : hourly.items.length;
        const warnings = [...hourly.warnings];
        const fallbackOnError = isFallbackErrorFreshness(result.freshness);
        const allItems = hourly.items;
        const nowMs = Date.now();
        let selectedItems = allItems.slice(0, maxItems);
        if (mode === "1h" && maxItems === 24 && allItems.length > 24) {
            const currentIndexInAll = nearestItemIndex(allItems, nowMs);
            const currentItem = currentIndexInAll >= 0 ? allItems[currentIndexInAll] : null;
            const currentDayKey = currentItem ? localDateKey(currentItem.timestamp, location.timezone) : null;
            if (currentDayKey) {
                const sameDayItems = allItems.filter((item) => localDateKey(item.timestamp, location.timezone) === currentDayKey);
                if (sameDayItems.length >= 24) {
                    selectedItems = sameDayItems.slice(0, 24);
                }
                else if (sameDayItems.length > 0) {
                    const selected = [...sameDayItems];
                    const seen = new Set(sameDayItems.map((item) => item.timestamp));
                    for (const item of allItems) {
                        if (seen.has(item.timestamp)) {
                            continue;
                        }
                        selected.push(item);
                        if (selected.length >= 24) {
                            break;
                        }
                    }
                    selectedItems = selected.slice(0, 24);
                }
            }
        }
        if (mode === "1h" && maxItems >= 24 && selectedItems.length < 24) {
            warnings.push("The parsed 1h view did not expose a full 24-hour window; returned the available hours.");
        }
        if (isRevalidatingFreshness(result.freshness)) {
            warnings.push("Background refresh is in progress; showing the most recent cached week page data.");
        }
        else if (fallbackOnError) {
            warnings.push("Serving stale week page data because the latest refresh failed.");
        }
        const sanitizedItems = sanitizeHourlyItems(selectedItems);
        const fieldCoverage = buildFieldCoverage({
            items: sanitizedItems,
            sourceType: hourly.sourceType,
            preferredItems: hourly.preferredItems,
            fallbackItems: hourly.fallbackItems,
            fieldDiagnostics: hourly.fieldDiagnostics,
        });
        const currentIndex = nearestItemIndex(sanitizedItems, nowMs);
        const current = currentIndex >= 0
            ? {
                timestamp: sanitizedItems[currentIndex]?.timestamp ?? "",
                temperatureC: sanitizedItems[currentIndex]?.temperatureC ?? null,
                index: currentIndex,
            }
            : null;
        const response = {
            location: {
                id: location.id,
                name: location.name,
                timezone: location.timezone,
            },
            fetchedAt: result.value.fetchedAt,
            sourceObservedAt: result.value.sourceObservedAt,
            mode,
            periodHours: mode === "1h" ? 1 : 3,
            sourceType: hourly.sourceType,
            stale: fallbackOnError,
            freshness: result.freshness,
            pageUrl: location.weekPageUrl,
            parserVersion: WEEK_PARSER_VERSION,
            items: sanitizedItems,
            fieldCoverage,
            partial: hourly.partial,
            warnings,
            cacheHit: result.cacheHit,
            current,
        };
        return response;
    }
    async getWeatherReport(locationId) {
        const location = this.requireLocation(locationId);
        const result = await this.getWeekCache(locationId).get({
            allowStaleOnError: true,
            staleWhileRevalidate: true,
        });
        const report = result.value.report;
        const warnings = [...report.warnings];
        const fallbackOnError = isFallbackErrorFreshness(result.freshness);
        const textZh = sanitizeReportTextZh({
            textZh: report.textZh,
            sourceTextEn: report.sourceTextEn,
            titleEn: report.titleEn,
            metrics: report.metrics,
            pageTemperatureUnit: location.fallbackDisplayUnit,
        });
        if (normalizeText(report.textZh ?? "") !== normalizeText(textZh)) {
            warnings.push("Weather report translation fallback applied.");
        }
        if (isRevalidatingFreshness(result.freshness)) {
            warnings.push("Background refresh is in progress; showing the most recent cached week page data.");
        }
        else if (fallbackOnError) {
            warnings.push("Serving stale week page data because the latest refresh failed.");
        }
        const response = {
            ...report,
            textZh,
            fetchedAt: result.value.fetchedAt,
            sourceObservedAt: result.value.sourceObservedAt,
            stale: fallbackOnError,
            freshness: result.freshness,
            cacheHit: result.cacheHit,
            warnings,
        };
        return response;
    }
    async getMultiModelImage(locationId, allowStale) {
        const location = this.requireLocation(locationId);
        try {
            const result = await this.getMultiModelImageCache(locationId).get({
                allowStaleOnError: allowStale,
                staleWhileRevalidate: allowStale,
            });
            const fallbackOnError = isFallbackErrorFreshness(result.freshness);
            const response = {
                contentType: result.value.contentType,
                body: result.value.body,
                cacheHit: result.cacheHit,
                stale: fallbackOnError,
                freshness: result.freshness,
                headers: {
                    "cache-control": allowStale ? "private, max-age=0, must-revalidate" : "no-store",
                    "x-weather-source": "meteoblue-web",
                    "x-weather-page-url": location.multimodelPageUrl,
                    "x-weather-page-fetched-at": result.value.pageFetchedAt,
                    "x-weather-image-fetched-at": result.value.imageFetchedAt,
                    "x-weather-stale": String(fallbackOnError),
                    "x-weather-freshness": result.freshness,
                    "x-weather-parser-version": MULTIMODEL_IMAGE_VERSION,
                },
            };
            return response;
        }
        catch {
            const snapshot = this.getMultiModelImageCache(locationId).peek();
            throw new AppError(503, "MULTIMODEL_IMAGE_UNAVAILABLE", "Could not fetch the official meteoblue multimodel image.", {
                retryable: true,
                staleAvailable: snapshot.entry !== null,
                lastSuccessAt: snapshot.entry?.value.imageFetchedAt ?? null,
            });
        }
    }
    async getMultiModelStatus(locationId) {
        const location = this.requireLocation(locationId);
        const distributionCache = this.getMultiModelDistributionCache(locationId);
        const snapshot = this.getMultiModelImageCache(locationId).peek();
        const distributionSnapshot = distributionCache.peek();
        const imageInFlight = snapshot.inFlight;
        const analysisInFlight = distributionSnapshot.inFlight;
        const resolvedImageUrl = snapshot.entry?.value.imageUrl ?? distributionSnapshot.entry?.value.pngUrl ?? null;
        const imageUrlFound = resolvedImageUrl !== null;
        const imageFreshness = resolveSnapshotFreshness(snapshot) ?? (imageInFlight ? "revalidating" : "fresh");
        const analysisFreshness = resolveSnapshotFreshness(distributionSnapshot) ?? (analysisInFlight ? "revalidating" : "fresh");
        const imageStatus = snapshot.entry || imageUrlFound
            ? imageInFlight
                ? "revalidating"
                : "ready"
            : imageInFlight
                ? "revalidating"
                : "unavailable";
        const hasAnalysisFallback = analysisFreshness === "fallback_error" && distributionSnapshot.entry !== null;
        const analysisStatus = hasAnalysisFallback
            ? "fallback_error"
            : distributionSnapshot.entry
                ? analysisInFlight
                    ? "revalidating"
                    : "ready"
                : analysisInFlight
                    ? "revalidating"
                    : "unavailable";
        const freshness = imageFreshness === "fallback_error" || analysisFreshness === "fallback_error"
            ? "fallback_error"
            : imageInFlight || analysisInFlight
                ? "revalidating"
                : "fresh";
        const displayUnit = location.fallbackDisplayUnit;
        return {
            location: {
                id: location.id,
                name: location.name,
                timezone: location.timezone,
            },
            displayUnit,
            fallbackDisplayUnit: displayUnit,
            pageFetchedAt: snapshot.entry?.value.pageFetchedAt ?? distributionSnapshot.entry?.value.pageFetchedAt ?? null,
            imageFetchedAt: snapshot.entry?.value.imageFetchedAt ?? null,
            imageUrlFound,
            cacheHit: (snapshot.entry !== null && snapshot.entry.expiresAt > Date.now()) ||
                (distributionSnapshot.entry !== null && distributionSnapshot.entry.expiresAt > Date.now()),
            stale: freshness === "fallback_error",
            freshness,
            imageStatus,
            analysisStatus,
            lastError: snapshot.lastError ?? distributionSnapshot.lastError,
            lastSuccessAt: snapshot.entry?.value.imageFetchedAt ?? distributionSnapshot.lastSuccessAt,
            imageUrl: resolvedImageUrl,
            pageUrl: location.multimodelPageUrl,
        };
    }
    async getMultiModelDistribution(locationId, timestamp, bucketSizeC = 1) {
        const location = this.requireLocation(locationId);
        try {
            const result = await this.getMultiModelDistributionCache(locationId).get({
                allowStaleOnError: true,
            });
            const fallbackOnError = isFallbackErrorFreshness(result.freshness);
            const response = buildMultiModelDistributionResponse(result.value, {
                id: location.id,
                name: location.name,
                timezone: location.timezone,
            }, location.multimodelPageUrl, timestamp, new Date().toISOString(), bucketSizeC, {
                stale: fallbackOnError,
                cacheHit: result.cacheHit,
                freshnessState: result.freshness,
            });
            if (isRevalidatingFreshness(result.freshness)) {
                response.warnings.push("Background refresh is in progress; showing the most recent cached multimodel statistics.");
            }
            else if (fallbackOnError) {
                response.warnings.push("Serving stale page-derived multimodel statistics because the latest highcharts refresh failed.");
            }
            return response;
        }
        catch (error) {
            const snapshot = this.getMultiModelDistributionCache(locationId).peek();
            if (error instanceof AppError) {
                throw new AppError(error.statusCode, error.code, error.message, {
                    retryable: error.retryable,
                    staleAvailable: error.staleAvailable || snapshot.entry !== null,
                    lastSuccessAt: error.lastSuccessAt ?? snapshot.lastSuccessAt,
                });
            }
            throw new AppError(503, "MULTIMODEL_DISTRIBUTION_UNAVAILABLE", error instanceof Error ? error.message : "Could not load multimodel distribution.", {
                retryable: true,
                staleAvailable: snapshot.entry !== null,
                lastSuccessAt: snapshot.lastSuccessAt,
            });
        }
    }
    async getMultiModelInsight(locationId, timestamp, actualTemperatureC) {
        const location = this.requireLocation(locationId);
        try {
            const result = await this.getMultiModelDistributionCache(locationId).get({
                allowStaleOnError: true,
            });
            const fallbackOnError = isFallbackErrorFreshness(result.freshness);
            const response = buildMultiModelInsightResponse(result.value, {
                id: location.id,
                name: location.name,
                timezone: location.timezone,
            }, location.multimodelPageUrl, {
                requestedTimestamp: timestamp,
                actualTemperatureC,
                nowIso: new Date().toISOString(),
            }, {
                stale: fallbackOnError,
                cacheHit: result.cacheHit,
                freshnessState: result.freshness,
            });
            if (isRevalidatingFreshness(result.freshness)) {
                response.warnings.push("Background refresh is in progress; showing the most recent cached multimodel insights.");
            }
            else if (fallbackOnError) {
                response.warnings.push("Serving stale page-derived multimodel insights because the latest highcharts refresh failed.");
            }
            return response;
        }
        catch (error) {
            const snapshot = this.getMultiModelDistributionCache(locationId).peek();
            if (error instanceof AppError) {
                throw new AppError(error.statusCode, error.code, error.message, {
                    retryable: error.retryable,
                    staleAvailable: error.staleAvailable || snapshot.entry !== null,
                    lastSuccessAt: error.lastSuccessAt ?? snapshot.lastSuccessAt,
                });
            }
            throw new AppError(503, "MULTIMODEL_INSIGHT_UNAVAILABLE", error instanceof Error ? error.message : "Could not load multimodel insights.", {
                retryable: true,
                staleAvailable: snapshot.entry !== null,
                lastSuccessAt: snapshot.lastSuccessAt,
            });
        }
    }
    async getKellyWorkbench(locationId, options = {}) {
        const location = this.requireLocation(locationId);
        const targetDate = resolveKellyTargetDate(location.timezone, options.targetDate);
        const cacheKey = buildKellySnapshotRequestKey(locationId, targetDate, options);
        const forceRefresh = options.forceRefresh === true;
        const fallbackSnapshot = this.readKellySnapshotResult(cacheKey, { includeExpired: true });
        if (!forceRefresh) {
            const cached = this.readKellySnapshotResult(cacheKey);
            if (cached) {
                return cached;
            }
        }
        if (!forceRefresh) {
            const existing = this.kellySnapshotInFlight.get(cacheKey);
            if (existing) {
                return await existing;
            }
        }
        const task = withTimeout(this.buildKellyWorkbenchSnapshot(locationId, location, targetDate, options), KELLY_WORKBENCH_TOTAL_TIMEOUT_MS, () => new AppError(504, "KELLY_WORKBENCH_TIMEOUT", `Kelly snapshot refresh exceeded ${KELLY_WORKBENCH_TOTAL_TIMEOUT_MS}ms.`, {
            retryable: true,
            staleAvailable: fallbackSnapshot !== null,
            lastSuccessAt: fallbackSnapshot?.generatedAt ?? this.kellyRuntimeHealth.lastSnapshotSuccessAt,
        }))
            .then((snapshot) => {
            this.kellySnapshotResults.set(cacheKey, {
                expiresAt: Date.now() + KELLY_SNAPSHOT_RESULT_TTL_MS,
                snapshot,
            });
            this.writeKellyStreamModelContext(cacheKey, snapshot.probabilityCurve, snapshot.distributionSummary.shrink);
            return snapshot;
        })
            .catch((error) => {
            if (forceRefresh && fallbackSnapshot) {
                return this.buildKellyFallbackSnapshotFromCache(fallbackSnapshot, error);
            }
            throw error;
        });
        this.kellySnapshotInFlight.set(cacheKey, task);
        try {
            return await task;
        }
        finally {
            if (this.kellySnapshotInFlight.get(cacheKey) === task) {
                this.kellySnapshotInFlight.delete(cacheKey);
            }
        }
    }
    async buildKellyWorkbenchSnapshot(locationId, location, targetDate, options) {
        const stageTimings = {};
        const totalStartedAt = Date.now();
        try {
            const [hourly, report, metarResult] = await Promise.all([
                measureAsync(stageTimings, "hourly", async () => await this.getHourly(locationId, "1h", 24)),
                measureAsync(stageTimings, "report", async () => await this.getWeatherReport(locationId)),
                measureAsync(stageTimings, "metar", async () => await this.getMetarCache(locationId).get({
                    allowStaleOnError: true,
                    forceRefresh: options.forceRefresh,
                })),
            ]);
            const metarObservation = metarResult.value.observation
                ? {
                    ...metarResult.value.observation,
                    stale: metarResult.stale,
                    freshness: metarResult.freshness,
                    cacheHit: metarResult.cacheHit,
                }
                : null;
            const resolvedActualTemperatureForInsight = options.actualTemperatureC ??
                metarObservation?.temperatureC ??
                hourly.current?.temperatureC ??
                undefined;
            const insight = await measureAsync(stageTimings, "insight", async () => await this.getMultiModelInsight(locationId, options.selectedHourTimestamp, resolvedActualTemperatureForInsight));
            const distributionSelection = resolveKellyDistributionSelection(insight.availableTimestamps, targetDate, location.timezone);
            const targetDistributionTimestamp = distributionSelection.timestamp;
            const effectiveTargetDate = distributionSelection.effectiveTargetDate;
            if (!targetDistributionTimestamp) {
                throw new AppError(400, "BAD_REQUEST", `Query parameter 'targetDate' is not available for this location: '${targetDate}'.`);
            }
            const distribution = await measureAsync(stageTimings, "distribution", async () => await this.getMultiModelDistribution(locationId, targetDistributionTimestamp, 1));
            const warnings = [];
            if (distributionSelection.usedFallback) {
                warnings.push(`Requested Kelly targetDate '${distributionSelection.requestedTargetDate}' is unavailable; auto-fallback to '${effectiveTargetDate}'.`);
            }
            if (!options.actualTemperatureC && metarObservation === null) {
                warnings.push("METAR 实况当前不可用，Kelly 下界约束回退到站点当前小时温度。");
            }
            else if (metarObservation?.stale) {
                warnings.push("METAR 实况当前使用最近一次成功缓存。");
            }
            const strictMarketRefresh = options.forceRefresh === true;
            let discoveryResult = null;
            let discoveryFetchedAt = null;
            try {
                const marketResult = await measureAsync(stageTimings, "marketDiscovery", async () => await this.getKellyMarketCache(locationId, effectiveTargetDate).get({
                    allowStaleOnError: true,
                    forceRefresh: options.forceRefresh,
                }));
                discoveryResult = marketResult.value;
                discoveryFetchedAt = discoveryResult.fetchedAt;
                if (marketResult.stale) {
                    warnings.push("Polymarket 市场目录刷新失败，当前使用最近一次成功缓存。");
                }
                warnings.push(...buildDiscoveryWarnings([
                    ...discoveryResult.candidates,
                    ...discoveryResult.inactiveCandidates,
                ]));
            }
            catch (error) {
                if (strictMarketRefresh) {
                    throw error;
                }
                warnings.push("Polymarket 市场目录暂时不可用，当前仅展示天气侧推导结果。");
            }
            let orderBooks = new Map();
            let orderbookObservedAt = null;
            if (discoveryResult?.candidates.some((candidate) => candidate.parseStatus === "matched")) {
                try {
                    const orderBookResult = await measureAsync(stageTimings, "orderbook", async () => await this.getKellyOrderBookCache(locationId, effectiveTargetDate).get({
                        allowStaleOnError: !strictMarketRefresh,
                        forceRefresh: options.forceRefresh,
                    }));
                    orderBooks = orderBookResult.value;
                    orderbookObservedAt = resolveLatestOrderbookTimestamp(orderBooks);
                    if (orderBookResult.stale) {
                        warnings.push("Polymarket 盘口快照刷新失败，当前使用最近一次成功缓存。");
                    }
                }
                catch (error) {
                    if (strictMarketRefresh) {
                        throw error;
                    }
                    warnings.push("Polymarket 盘口快照暂时不可用，当前仅展示公允概率与档位匹配。");
                }
            }
            const pricingStartedAt = Date.now();
            const generatedAt = new Date().toISOString();
            const cacheKey = buildKellyCacheKey(locationId, effectiveTargetDate);
            const existingFrameSeries = this.kellyFrameHistories.get(cacheKey) ?? [];
            const hasActionableBookData = [...orderBooks.values()].some((book) => book.bestAsk !== null || book.bestBid !== null);
            const repricedAt = hasActionableBookData ? generatedAt : null;
            const observationFloor = this.resolveKellyObservationFloor(location, effectiveTargetDate, hourly, metarObservation, metarResult.value.recentTemperatures, options);
            const baseSnapshot = buildKellyWorkbench({
                location,
                targetDate: effectiveTargetDate,
                hourly,
                report,
                metarObservation,
                insight,
                distribution,
                discoveryCandidates: discoveryResult?.candidates ?? [],
                inactiveCandidates: discoveryResult?.inactiveCandidates ?? [],
                discoveryFetchedAt,
                sourceLinks: discoveryResult?.sourceLinks ?? {
                    meteoblueWeekUrl: location.weekPageUrl,
                    meteoblueMultimodelUrl: location.multimodelPageUrl,
                    polymarketSearchUrl: `${config.polymarketGammaBaseUrl}/public-search?q=${encodeURIComponent(`${location.cityName} weather ${effectiveTargetDate}`)}`,
                    marketUrls: [],
                },
                orderBooks,
                priceFetchedAt: orderbookObservedAt,
                generatedAt,
                repricedAt,
                frameSeries: existingFrameSeries,
                options,
                warnings,
                observationFloorOverride: observationFloor,
            });
            const frameSeries = this.rememberKellyFrameHistory(locationId, effectiveTargetDate, buildReadableFramePoints(baseSnapshot.markets, generatedAt), generatedAt);
            const snapshot = buildKellyWorkbench({
                location,
                targetDate: effectiveTargetDate,
                hourly,
                report,
                metarObservation,
                insight,
                distribution,
                discoveryCandidates: discoveryResult?.candidates ?? [],
                inactiveCandidates: discoveryResult?.inactiveCandidates ?? [],
                discoveryFetchedAt,
                sourceLinks: discoveryResult?.sourceLinks ?? {
                    meteoblueWeekUrl: location.weekPageUrl,
                    meteoblueMultimodelUrl: location.multimodelPageUrl,
                    polymarketSearchUrl: `${config.polymarketGammaBaseUrl}/public-search?q=${encodeURIComponent(`${location.cityName} weather ${effectiveTargetDate}`)}`,
                    marketUrls: [],
                },
                orderBooks,
                priceFetchedAt: orderbookObservedAt,
                generatedAt,
                repricedAt,
                frameSeries,
                options,
                warnings,
                observationFloorOverride: observationFloor,
            });
            stageTimings.pricing = Date.now() - pricingStartedAt;
            stageTimings.total = Date.now() - totalStartedAt;
            this.recordKellySnapshotSuccess({
                generatedAt,
                discoveryFetchedAt,
                orderbookFetchedAt: orderbookObservedAt,
                repricedAt,
                stageTimings,
            });
            return {
                ...snapshot,
                // Keep the frame history on the bridge for repricing and audits, but
                // stop shipping it to the main Kelly page. That materially cuts GET
                // payload size during rapid location switches while preserving the API
                // field for compatibility.
                frameSeries: [],
            };
        }
        catch (error) {
            stageTimings.total = Date.now() - totalStartedAt;
            this.recordKellySnapshotFailure(error, stageTimings);
            throw error;
        }
    }
    ensureKellyStreamHub(locationId, location, targetDate, tokenIds) {
        const key = buildKellyCacheKey(locationId, targetDate);
        let hub = this.kellyStreamHubs.get(key);
        let tokensExpanded = false;
        if (!hub) {
            hub = {
                key,
                locationId,
                location,
                targetDate,
                tokenIds: new Set(),
                subscribers: new Map(),
                upstreamStream: null,
                upstreamConnected: false,
                lastSignalAt: null,
                lastRepricedAt: null,
                lastOrderbookAt: null,
                latestBooks: null,
                pendingTimer: null,
                fallbackTimer: null,
                idleTimer: null,
                repriceInFlight: null,
            };
            this.kellyStreamHubs.set(key, hub);
            this.syncKellyHubCount();
        }
        if (hub.idleTimer) {
            clearTimeout(hub.idleTimer);
            hub.idleTimer = null;
        }
        for (const tokenId of tokenIds.filter(Boolean)) {
            if (!hub.tokenIds.has(tokenId)) {
                hub.tokenIds.add(tokenId);
                tokensExpanded = true;
            }
        }
        return { hub, tokensExpanded };
    }
    sendKellyStreamSubscriberMessage(subscriber, message, options) {
        if (subscriber.closed) {
            return;
        }
        subscriber.lastClientMessageAt = Date.now();
        this.recordKellyStreamEvent(message.generatedAt, options?.fallbackMode);
        subscriber.onMessage(message);
    }
    broadcastKellyStreamHubStatus(hub, buildMessage, options) {
        for (const subscriber of hub.subscribers.values()) {
            this.sendKellyStreamSubscriberMessage(subscriber, buildMessage(subscriber), options);
        }
    }
    stopKellyStreamSubscriberKeepalive(subscriber) {
        if (subscriber.keepaliveTimer) {
            clearInterval(subscriber.keepaliveTimer);
            subscriber.keepaliveTimer = null;
        }
    }
    startKellyStreamSubscriberKeepalive(hub, subscriber) {
        if (subscriber.keepaliveTimer) {
            return;
        }
        subscriber.keepaliveTimer = setInterval(() => {
            if (subscriber.closed || Date.now() - subscriber.lastClientMessageAt < KELLY_STREAM_CLIENT_KEEPALIVE_MS) {
                return;
            }
            if (!hub.fallbackTimer && !hub.upstreamConnected) {
                return;
            }
            const generatedAt = new Date().toISOString();
            if (hub.fallbackTimer) {
                this.sendKellyStreamSubscriberMessage(subscriber, {
                    type: "status",
                    generatedAt,
                    state: "degraded",
                    reasonCode: "polling_fallback",
                    message: subscriber.lastRepricedAt
                        ? "实时流异常，当前回退到轮询；最近一次轮询重定价仍有效。"
                        : "实时流异常，当前回退到轮询盘口同步。",
                    lastSignalAt: hub.lastSignalAt,
                    lastRepricedAt: subscriber.lastRepricedAt,
                }, { fallbackMode: true });
                return;
            }
            this.sendKellyStreamSubscriberMessage(subscriber, {
                type: "status",
                generatedAt,
                state: "connected",
                reasonCode: "no_recent_market_motion",
                message: hub.lastSignalAt ? "实时流已连接，最近没有新的盘口变动。" : "实时流已连接，正在等待新的盘口变动。",
                lastSignalAt: hub.lastSignalAt,
                lastRepricedAt: subscriber.lastRepricedAt,
            });
        }, KELLY_STREAM_CLIENT_KEEPALIVE_MS);
    }
    async closeKellyStreamHub(hub) {
        if (hub.pendingTimer) {
            clearTimeout(hub.pendingTimer);
            hub.pendingTimer = null;
        }
        if (hub.fallbackTimer) {
            clearInterval(hub.fallbackTimer);
            hub.fallbackTimer = null;
        }
        if (hub.idleTimer) {
            clearTimeout(hub.idleTimer);
            hub.idleTimer = null;
        }
        hub.upstreamConnected = false;
        const upstreamStream = hub.upstreamStream;
        hub.upstreamStream = null;
        hub.latestBooks = null;
        this.kellyStreamHubs.delete(hub.key);
        this.syncKellyHubCount();
        this.syncKellyFallbackMode();
        if (upstreamStream) {
            await upstreamStream.close();
        }
    }
    async releaseKellyStreamSubscriber(hub, subscriberId) {
        const subscriber = hub.subscribers.get(subscriberId);
        if (!subscriber) {
            return;
        }
        subscriber.closed = true;
        this.stopKellyStreamSubscriberKeepalive(subscriber);
        hub.subscribers.delete(subscriberId);
        this.kellyRuntimeHealth.openStreamCount = Math.max(0, this.kellyRuntimeHealth.openStreamCount - 1);
        if (hub.subscribers.size === 0 && !hub.idleTimer) {
            hub.idleTimer = setTimeout(() => {
                hub.idleTimer = null;
                if (hub.subscribers.size === 0) {
                    void this.closeKellyStreamHub(hub);
                }
            }, KELLY_STREAM_HUB_IDLE_TTL_MS);
        }
    }
    async ensureKellyStreamHubUpstream(hub, restart) {
        if (hub.subscribers.size === 0) {
            return;
        }
        if (restart && hub.upstreamStream) {
            const previous = hub.upstreamStream;
            hub.upstreamStream = null;
            hub.upstreamConnected = false;
            await previous.close();
        }
        if (hub.upstreamStream) {
            return;
        }
        hub.upstreamStream = this.polymarketClient.createMarketStream([...hub.tokenIds], (message) => {
            if (message.type === "status") {
                if (message.state === "connected") {
                    hub.upstreamConnected = true;
                    this.stopKellyStreamHubPollingFallback(hub);
                }
                else if (message.state === "degraded" || message.state === "disconnected") {
                    hub.upstreamConnected = false;
                    this.startKellyStreamHubPollingFallback(hub);
                }
            }
            this.broadcastKellyStreamHubStatus(hub, (subscriber) => ({
                ...message,
                lastSignalAt: hub.lastSignalAt,
                lastRepricedAt: subscriber.lastRepricedAt ?? message.lastRepricedAt ?? null,
            }), {
                fallbackMode: message.type === "status" && message.reasonCode === "polling_fallback",
            });
        }, (occurredAt) => {
            hub.lastSignalAt = occurredAt;
            this.recordKellySignal(occurredAt);
            if (hub.pendingTimer) {
                return;
            }
            hub.pendingTimer = setTimeout(() => {
                hub.pendingTimer = null;
                if (hub.subscribers.size === 0) {
                    return;
                }
                void this.emitKellyStreamHubSnapshots(hub);
            }, KELLY_STREAM_REPRICE_DEBOUNCE_MS);
        });
    }
    startKellyStreamHubPollingFallback(hub) {
        if (hub.fallbackTimer) {
            return;
        }
        const fallbackTime = new Date().toISOString();
        this.recordKellyStreamEvent(fallbackTime, true);
        this.broadcastKellyStreamHubStatus(hub, (subscriber) => ({
            type: "status",
            generatedAt: fallbackTime,
            state: "degraded",
            reasonCode: "polling_fallback",
            message: "实时流异常，已回退到轮询盘口同步。",
            lastSignalAt: hub.lastSignalAt,
            lastRepricedAt: subscriber.lastRepricedAt,
        }), { fallbackMode: true });
        hub.fallbackTimer = setInterval(() => {
            if (hub.subscribers.size === 0) {
                return;
            }
            void this.emitKellyStreamHubSnapshots(hub).then((repricedAt) => {
                if (!repricedAt) {
                    return;
                }
                this.broadcastKellyStreamHubStatus(hub, (subscriber) => ({
                    type: "status",
                    generatedAt: new Date().toISOString(),
                    state: "degraded",
                    reasonCode: "polling_fallback",
                    message: "实时流异常，当前已回退到轮询；最近一次轮询重定价成功。",
                    lastSignalAt: hub.lastSignalAt,
                    lastRepricedAt: subscriber.lastRepricedAt ?? repricedAt,
                }), { fallbackMode: true });
            });
        }, KELLY_STREAM_POLLING_INTERVAL_MS);
        this.syncKellyFallbackMode();
    }
    stopKellyStreamHubPollingFallback(hub) {
        if (hub.fallbackTimer) {
            clearInterval(hub.fallbackTimer);
            hub.fallbackTimer = null;
        }
        this.syncKellyFallbackMode();
    }
    async loadKellyStreamHubBooks(hub, options) {
        if (options?.reuseExistingBooks && hub.latestBooks) {
            return {
                books: hub.latestBooks,
                generatedAt: new Date().toISOString(),
                orderbookObservedAt: hub.lastOrderbookAt,
            };
        }
        const tokenIds = [...hub.tokenIds];
        const orderBookCache = this.getKellyOrderBookCache(hub.locationId, hub.targetDate);
        const cachedBooks = hub.latestBooks ?? orderBookCache.peek().entry?.value ?? null;
        const freshBooks = await this.fetchFreshKellyOrderBooks(hub.locationId, hub.targetDate, tokenIds);
        if (freshBooks.size === 0 && cachedBooks && cachedBooks.size > 0) {
            throw new AppError(503, "POLYMARKET_ORDERBOOK_REFRESH_EMPTY", "Polymarket orderbook refresh returned no fresh books.", {
                retryable: true,
            });
        }
        const books = this.mergeKellyOrderBooks(tokenIds, freshBooks, cachedBooks);
        const generatedAt = new Date().toISOString();
        const orderbookObservedAt = resolveLatestOrderbookTimestamp(books);
        orderBookCache.set(books, new Date(generatedAt));
        this.invalidateKellySnapshotResults(hub.locationId, hub.targetDate);
        hub.latestBooks = books;
        hub.lastOrderbookAt = orderbookObservedAt;
        this.kellyRuntimeHealth.lastOrderbookAt = orderbookObservedAt ?? this.kellyRuntimeHealth.lastOrderbookAt;
        return {
            books,
            generatedAt,
            orderbookObservedAt,
        };
    }
    handleKellyStreamSubscriberRepriceFailure(hub, subscriber, error) {
        const failedAt = new Date().toISOString();
        const retainedSnapshot = this.readKellyStreamLastGoodSnapshot(subscriber.streamContextKey);
        const hasRetainedSnapshot = Boolean(retainedSnapshot?.repricedMarkets.length);
        const preservedLastRepricedAt = retainedSnapshot?.repricedAt ?? subscriber.lastRepricedAt;
        if (retainedSnapshot && retainedSnapshot.repricedMarkets.length > 0) {
            this.sendKellyStreamSubscriberMessage(subscriber, {
                type: "markets",
                generatedAt: failedAt,
                markets: buildStreamMarketPatches(retainedSnapshot.repricedMarkets),
                frames: retainedSnapshot.framePoints,
                lastSignalAt: hub.lastSignalAt,
                lastRepricedAt: retainedSnapshot.repricedAt,
            });
            subscriber.lastRepricedAt = retainedSnapshot.repricedAt;
        }
        subscriber.consecutiveRepriceFailures += 1;
        console.warn("[kelly-stream:reprice-failed]", {
            locationId: hub.locationId,
            targetDate: hub.targetDate,
            reasonCode: "reprice_failed",
            lastSignalAt: hub.lastSignalAt,
            lastRepricedAt: preservedLastRepricedAt,
            dataRetained: hasRetainedSnapshot,
            consecutiveRepriceFailures: subscriber.consecutiveRepriceFailures,
            subscriberCount: hub.subscribers.size,
            hubKey: hub.key,
            error: error instanceof Error ? error.message : String(error),
        });
        if (subscriber.consecutiveRepriceFailures >= KELLY_STREAM_REPRICE_FAILURE_WARN_THRESHOLD) {
            console.warn("[kelly-stream:reprice-failure-threshold]", {
                locationId: hub.locationId,
                targetDate: hub.targetDate,
                threshold: KELLY_STREAM_REPRICE_FAILURE_WARN_THRESHOLD,
                consecutiveRepriceFailures: subscriber.consecutiveRepriceFailures,
                lastSignalAt: hub.lastSignalAt,
                lastRepricedAt: preservedLastRepricedAt,
                dataRetained: hasRetainedSnapshot,
                subscriberCount: hub.subscribers.size,
                hubKey: hub.key,
            });
        }
        this.sendKellyStreamSubscriberMessage(subscriber, {
            type: "status",
            generatedAt: failedAt,
            state: "degraded",
            reasonCode: "reprice_failed",
            message: hasRetainedSnapshot
                ? "实时流收到信号，本轮重定价失败；当前沿用上一轮结果并等待下一次同步。"
                : preservedLastRepricedAt
                    ? "实时流收到信号，本轮重定价失败；当前沿用上一轮结果并等待下一次同步。"
                    : "实时流收到信号，但本轮盘口同步失败。",
            lastSignalAt: hub.lastSignalAt,
            lastRepricedAt: preservedLastRepricedAt,
        });
        return preservedLastRepricedAt;
    }
    async emitKellyStreamHubSnapshots(hub, options) {
        if (hub.repriceInFlight) {
            return await hub.repriceInFlight;
        }
        const task = (async () => {
            const targetSubscribers = options?.subscriberId
                ? [hub.subscribers.get(options.subscriberId)].filter((value) => Boolean(value))
                : [...hub.subscribers.values()];
            if (targetSubscribers.length === 0) {
                return null;
            }
            let sharedBooks;
            try {
                sharedBooks = await this.loadKellyStreamHubBooks(hub, {
                    reuseExistingBooks: options?.reuseExistingBooks,
                });
            }
            catch (error) {
                let preservedLastRepricedAt = null;
                for (const subscriber of targetSubscribers) {
                    preservedLastRepricedAt =
                        this.handleKellyStreamSubscriberRepriceFailure(hub, subscriber, error) ?? preservedLastRepricedAt;
                }
                this.startKellyStreamHubPollingFallback(hub);
                return preservedLastRepricedAt;
            }
            let latestRepricedAt = null;
            let successCount = 0;
            let failureCount = 0;
            for (const subscriber of targetSubscribers) {
                try {
                    const { framePoints, generatedAt, orderbookObservedAt, repricedAt, repricedMarkets } = await this.repriceKellyStreamSnapshot({
                        locationId: hub.locationId,
                        location: hub.location,
                        targetDate: hub.targetDate,
                        options: subscriber.streamOptions,
                        matchedMarkets: subscriber.matchedMarkets,
                        trackedMarkets: subscriber.trackedMarkets,
                        bankroll: subscriber.bankroll,
                        riskMode: subscriber.riskMode,
                        minEdge: subscriber.minEdge,
                        probabilityCurve: subscriber.probabilityCurve,
                        shrink: subscriber.shrink,
                        booksOverride: sharedBooks.books,
                        generatedAtOverride: sharedBooks.generatedAt,
                        orderbookObservedAtOverride: sharedBooks.orderbookObservedAt,
                    });
                    this.writeKellyStreamLastGoodSnapshot(subscriber.streamContextKey, {
                        generatedAt,
                        repricedAt,
                        repricedMarkets,
                        framePoints,
                    });
                    subscriber.lastRepricedAt = repricedAt;
                    subscriber.consecutiveRepriceFailures = 0;
                    hub.lastRepricedAt = repricedAt;
                    latestRepricedAt = repricedAt;
                    successCount += 1;
                    this.kellyRuntimeHealth.lastOrderbookAt = orderbookObservedAt ?? this.kellyRuntimeHealth.lastOrderbookAt;
                    this.kellyRuntimeHealth.lastRepricedAt = repricedAt;
                    console.info("[kelly-stream:reprice]", {
                        locationId: hub.locationId,
                        targetDate: hub.targetDate,
                        reasonCode: "repriced",
                        lastSignalAt: hub.lastSignalAt,
                        lastRepricedAt: repricedAt,
                        dataRetained: false,
                        subscriberCount: hub.subscribers.size,
                        hubKey: hub.key,
                    });
                    this.sendKellyStreamSubscriberMessage(subscriber, {
                        type: "markets",
                        generatedAt,
                        markets: buildStreamMarketPatches(repricedMarkets),
                        frames: framePoints,
                        lastSignalAt: hub.lastSignalAt,
                        lastRepricedAt: repricedAt,
                    });
                }
                catch (error) {
                    failureCount += 1;
                    latestRepricedAt = this.handleKellyStreamSubscriberRepriceFailure(hub, subscriber, error) ?? latestRepricedAt;
                }
            }
            if (successCount > 0 && hub.upstreamConnected) {
                this.stopKellyStreamHubPollingFallback(hub);
            }
            else if (failureCount > 0 && successCount === 0) {
                this.startKellyStreamHubPollingFallback(hub);
            }
            return latestRepricedAt;
        })();
        hub.repriceInFlight = task;
        try {
            return await task;
        }
        finally {
            if (hub.repriceInFlight === task) {
                hub.repriceInFlight = null;
            }
        }
    }
    async createKellyStream(locationId, options, onMessage) {
        const location = this.requireLocation(locationId);
        const requestedTargetDate = resolveKellyTargetDate(location.timezone, options.targetDate);
        const snapshot = await this.getKellyWorkbench(locationId, {
            ...options,
            targetDate: requestedTargetDate,
        });
        const targetDate = snapshot.targetDate || requestedTargetDate;
        const streamOptions = {
            ...options,
            targetDate,
            bankroll: snapshot.bankroll,
            riskMode: snapshot.riskMode,
            minEdge: snapshot.minEdge,
        };
        const streamContextKey = buildKellySnapshotRequestKey(locationId, targetDate, {
            ...streamOptions,
        });
        this.writeKellyStreamModelContext(streamContextKey, snapshot.probabilityCurve, snapshot.distributionSummary.shrink);
        const streamCandidates = [...snapshot.markets, ...(snapshot.inactiveMarkets ?? [])];
        const trackedMarkets = streamCandidates.filter((market) => market.parseStatus === "matched");
        const matchedMarkets = trackedMarkets.filter((market) => Boolean(market.yesTokenId && market.noTokenId));
        const seededRepricedAt = snapshot.freshness.repricedAt ?? snapshot.generatedAt;
        if (matchedMarkets.length > 0) {
            this.writeKellyStreamLastGoodSnapshot(streamContextKey, {
                generatedAt: snapshot.generatedAt,
                repricedAt: seededRepricedAt,
                repricedMarkets: trackedMarkets,
                framePoints: [],
            });
        }
        if (!matchedMarkets.length) {
            this.recordKellyStreamEvent(new Date().toISOString(), false);
            onMessage({
                type: "status",
                generatedAt: new Date().toISOString(),
                state: "unavailable",
                reasonCode: "no_matched_markets",
                message: "当前没有可订阅的 Polymarket 盘口。",
                lastSignalAt: null,
                lastRepricedAt: null,
            });
            return {
                close() { },
            };
        }
        const { hub, tokensExpanded } = this.ensureKellyStreamHub(locationId, location, targetDate, matchedMarkets.flatMap((market) => [market.yesTokenId, market.noTokenId]));
        const subscriber = {
            id: `kelly-stream-${++this.kellyStreamSubscriberSequence}`,
            streamContextKey,
            onMessage,
            trackedMarkets,
            matchedMarkets,
            streamOptions,
            bankroll: snapshot.bankroll,
            riskMode: snapshot.riskMode,
            minEdge: snapshot.minEdge,
            probabilityCurve: snapshot.probabilityCurve,
            shrink: snapshot.distributionSummary.shrink,
            lastRepricedAt: seededRepricedAt ?? null,
            lastClientMessageAt: Date.now(),
            consecutiveRepriceFailures: 0,
            keepaliveTimer: null,
            closed: false,
        };
        hub.subscribers.set(subscriber.id, subscriber);
        this.kellyRuntimeHealth.openStreamCount += 1;
        this.startKellyStreamSubscriberKeepalive(hub, subscriber);
        await this.ensureKellyStreamHubUpstream(hub, tokensExpanded);
        if (hub.repriceInFlight) {
            await hub.repriceInFlight;
        }
        else if (hub.latestBooks) {
            await this.emitKellyStreamHubSnapshots(hub, {
                subscriberId: subscriber.id,
                reuseExistingBooks: true,
            });
        }
        else {
            await this.emitKellyStreamHubSnapshots(hub);
        }
        if (!subscriber.closed && hub.upstreamConnected) {
            this.sendKellyStreamSubscriberMessage(subscriber, {
                type: "status",
                generatedAt: new Date().toISOString(),
                state: "connected",
                reasonCode: "no_recent_market_motion",
                message: "实时流已连接，最近还没有新的盘口变动。",
                lastSignalAt: hub.lastSignalAt,
                lastRepricedAt: subscriber.lastRepricedAt,
            });
        }
        return {
            close: async () => {
                await this.releaseKellyStreamSubscriber(hub, subscriber.id);
            },
        };
    }
    async getUserFavorites() {
        const stored = await this.favoritesStore.getFavorites(new Set(this.allowedLocationIds));
        return {
            fetchedAt: stored.updatedAt,
            locationIds: stored.locationIds,
        };
    }
    async setUserFavorite(locationId, favorite) {
        if (!this.allowedLocationIds.has(locationId)) {
            throw new AppError(400, "BAD_REQUEST", `Unknown locationId '${locationId}'.`);
        }
        const stored = await this.favoritesStore.setFavorite(locationId, favorite, new Set(this.allowedLocationIds));
        return {
            fetchedAt: stored.updatedAt,
            locationIds: stored.locationIds,
        };
    }
}
