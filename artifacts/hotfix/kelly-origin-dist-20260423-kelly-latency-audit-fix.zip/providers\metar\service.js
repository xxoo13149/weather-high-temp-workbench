import { RefreshableCache } from "../../lib/cache.js";
import { fetchBinary, fetchJson } from "../../lib/http.js";
const METAR_API_BASE_URL = "https://aviationweather.gov/api/data/metar";
const METAR_SOURCE_URL_BASE = `${METAR_API_BASE_URL}?format=json&ids=`;
const METAR_CACHE_CSV_URL = "https://aviationweather.gov/data/cache/metars.cache.csv.gz";
const RECENT_METAR_HOURS = 24;
const METAR_CACHE_TTL_MS = 60_000;
const ICAO_BY_LOCATION = {
    amsterdam_ams: "EHAM",
    ankara_esb: "LTAC",
    atlanta_atl: "KATL",
    austin_aus: "KAUS",
    beijing_pek: "ZBAA",
    buenosaires_eze: "SAEZ",
    busan_pus: "RKPK",
    capetown_cpt: "FACT",
    chengdu_ctu: "ZUUU",
    chicago_ord: "KORD",
    chongqing_ckg: "ZUCK",
    dallas_dal: "KDAL",
    denver_bfk: "KBKF",
    guangzhou_can: "ZGGG",
    helsinki_hel: "EFHK",
    hongkong_hkg: "VHHH",
    houston_hou: "KHOU",
    shanghai_pvg: "ZSPD",
    istanbul_ist: "LTFM",
    jakarta_hlp: "WIHH",
    jeddah_jed: "OEJN",
    karachi_khi: "OPKC",
    kualalumpur_kul: "WMKK",
    lagos_los: "DNMM",
    london_lcy: "EGLC",
    lucknow_lko: "VILK",
    madrid_mad: "LEMD",
    manila_mnl: "RPLL",
    // OPMR currently has no public METAR feed on AviationWeather, so we temporarily fall back to the
    // nearby Karachi airport station to keep the city-level observation chain available.
    masroor_opmr: "OPKC",
    mexicocity_mex: "MMMX",
    milan_mxp: "LIMC",
    moscow_vko: "UUWW",
    munich_muc: "EDDM",
    miami_mia: "KMIA",
    newyork_lga: "KLGA",
    panamacity_pac: "MPMG",
    paris_cdg: "LFPG",
    losangeles_lax: "KLAX",
    sanfrancisco_sfo: "KSFO",
    saopaulo_gru: "SBGR",
    seattle_sea: "KSEA",
    seoul_icn: "RKSI",
    shenzhen_szx: "ZGSZ",
    singapore_sin: "WSSS",
    taipei_tpe: "RCTP",
    telaviv_tlv: "LLBG",
    tokyo_hnd: "RJTT",
    toronto_yyz: "CYYZ",
    warsaw_waw: "EPWA",
    wellington_wlg: "NZWN",
    wuhan_wuh: "ZHHH",
};
const toIsoTime = (value) => {
    if (typeof value === "string" && value.trim()) {
        const parsed = new Date(value);
        return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
    }
    if (typeof value === "number" && Number.isFinite(value)) {
        const millis = value > 1e12 ? value : value * 1000;
        const parsed = new Date(millis);
        return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
    }
    return null;
};
export const resolveMetarStationId = (locationId) => ICAO_BY_LOCATION[locationId] ?? null;
const buildMetarSourceUrl = (stationId, hours = RECENT_METAR_HOURS) => `${METAR_SOURCE_URL_BASE}${encodeURIComponent(stationId)}&hours=${hours}`;
const parseCsvLine = (line) => {
    const values = [];
    let current = "";
    let inQuotes = false;
    for (let index = 0; index < line.length; index += 1) {
        const char = line[index];
        if (char === '"') {
            if (inQuotes && line[index + 1] === '"') {
                current += '"';
                index += 1;
                continue;
            }
            inQuotes = !inQuotes;
            continue;
        }
        if (char === "," && !inQuotes) {
            values.push(current);
            current = "";
            continue;
        }
        current += char;
    }
    values.push(current);
    return values;
};
const parseNumber = (value) => {
    if (!value) {
        return null;
    }
    const parsed = Number.parseFloat(value);
    return Number.isFinite(parsed) ? parsed : null;
};
const decompressGzipUtf8 = async (body) => {
    if (typeof DecompressionStream !== "undefined") {
        const bytes = new Uint8Array(body);
        const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
        return await new Response(stream).text();
    }
    const { gunzipSync } = await import("node:zlib");
    return gunzipSync(body).toString("utf-8");
};
const loadCachedMetarIndex = async () => {
    const { body } = await fetchBinary(METAR_CACHE_CSV_URL, {
        headers: {
            accept: "text/csv,application/gzip,*/*",
        },
    });
    const csv = await decompressGzipUtf8(body);
    const [headerLine, ...lines] = csv.split(/\r?\n/).filter(Boolean);
    if (!headerLine) {
        return new Map();
    }
    const headers = parseCsvLine(headerLine);
    const getColumnIndex = (columnName) => headers.indexOf(columnName);
    const stationIdIndex = getColumnIndex("station_id");
    const observationTimeIndex = getColumnIndex("observation_time");
    const temperatureIndex = getColumnIndex("temp_c");
    const dewpointIndex = getColumnIndex("dewpoint_c");
    const windDirectionIndex = getColumnIndex("wind_dir_degrees");
    const windSpeedIndex = getColumnIndex("wind_speed_kt");
    const rawTextIndex = getColumnIndex("raw_text");
    if (stationIdIndex === -1 ||
        observationTimeIndex === -1 ||
        temperatureIndex === -1 ||
        dewpointIndex === -1 ||
        windDirectionIndex === -1 ||
        windSpeedIndex === -1 ||
        rawTextIndex === -1) {
        return new Map();
    }
    const index = new Map();
    for (const line of lines) {
        const row = parseCsvLine(line);
        const stationId = row[stationIdIndex]?.trim();
        const observedAt = toIsoTime(row[observationTimeIndex]);
        if (!stationId || !observedAt) {
            continue;
        }
        const existing = index.get(stationId);
        if (existing && existing.observedAt.localeCompare(observedAt) >= 0) {
            continue;
        }
        index.set(stationId, {
            stationId,
            observedAt,
            temperatureC: parseNumber(row[temperatureIndex]),
            dewpointC: parseNumber(row[dewpointIndex]),
            windDirectionDegrees: parseNumber(row[windDirectionIndex]),
            windSpeedKts: parseNumber(row[windSpeedIndex]),
            rawReport: row[rawTextIndex] || null,
        });
    }
    return index;
};
const metarCurrentCache = new RefreshableCache(METAR_CACHE_TTL_MS, loadCachedMetarIndex);
const getCachedLatestMetar = async (stationId) => {
    const result = await metarCurrentCache.get({
        allowStaleOnError: true,
        staleWhileRevalidate: true,
    });
    return result.value.get(stationId) ?? null;
};
export const __resetMetarTestState = () => {
    metarCurrentCache.invalidate();
};
const toTemperatureSamples = (payload) => payload
    .map((entry) => ({
    observedAt: toIsoTime(entry.reportTime) ?? toIsoTime(entry.obsTime) ?? toIsoTime(entry.receiptTime),
    temperatureC: typeof entry.temp === "number" ? entry.temp : null,
}))
    .filter((entry) => Boolean(entry.observedAt) && typeof entry.temperatureC === "number")
    .sort((left, right) => right.observedAt.localeCompare(left.observedAt));
const toObservationFromCache = (location, stationId, cached) => {
    const sourceUrl = buildMetarSourceUrl(stationId);
    return {
        observation: typeof cached.temperatureC === "number"
            ? {
                location,
                stationId,
                observedAt: cached.observedAt,
                temperatureC: cached.temperatureC,
                dewpointC: cached.dewpointC,
                windDirectionDegrees: cached.windDirectionDegrees,
                windSpeedKts: cached.windSpeedKts,
                rawReport: cached.rawReport,
                stationName: null,
                sourceUrl,
                fetchedAt: new Date().toISOString(),
                stale: false,
                freshness: "fresh",
                cacheHit: true,
            }
            : null,
        recentTemperatures: typeof cached.temperatureC === "number"
            ? [
                {
                    observedAt: cached.observedAt,
                    temperatureC: cached.temperatureC,
                },
            ]
            : [],
    };
};
export const fetchMetarSnapshot = async (location, hours = RECENT_METAR_HOURS) => {
    const stationId = resolveMetarStationId(location.id);
    if (!stationId) {
        return {
            observation: null,
            recentTemperatures: [],
        };
    }
    const sourceUrl = buildMetarSourceUrl(stationId, hours);
    const cachedLatest = await getCachedLatestMetar(stationId).catch(() => null);
    let payload;
    try {
        payload = await fetchJson(sourceUrl);
    }
    catch {
        if (cachedLatest) {
            return toObservationFromCache(location, stationId, cachedLatest);
        }
        // METAR is an auxiliary observation source; an upstream parse/fetch miss should degrade to no observation,
        // not take down the Kelly workbench for the whole city.
        return {
            observation: null,
            recentTemperatures: [],
        };
    }
    if (!Array.isArray(payload)) {
        return cachedLatest ? toObservationFromCache(location, stationId, cachedLatest) : { observation: null, recentTemperatures: [] };
    }
    const recentTemperatures = toTemperatureSamples(payload);
    const latest = payload
        .filter((entry) => typeof entry.temp === "number")
        .sort((left, right) => {
        const leftTime = toIsoTime(left.reportTime) ?? toIsoTime(left.obsTime) ?? toIsoTime(left.receiptTime) ?? "";
        const rightTime = toIsoTime(right.reportTime) ?? toIsoTime(right.obsTime) ?? toIsoTime(right.receiptTime) ?? "";
        return rightTime.localeCompare(leftTime);
    })[0];
    if (!latest || typeof latest.temp !== "number") {
        if (cachedLatest) {
            const snapshot = toObservationFromCache(location, stationId, cachedLatest);
            return {
                observation: snapshot.observation,
                recentTemperatures: recentTemperatures.length > 0 ? recentTemperatures : snapshot.recentTemperatures,
            };
        }
        return {
            observation: null,
            recentTemperatures,
        };
    }
    return {
        observation: {
            location,
            stationId,
            observedAt: toIsoTime(latest.reportTime) ?? toIsoTime(latest.obsTime) ?? toIsoTime(latest.receiptTime) ?? new Date().toISOString(),
            temperatureC: latest.temp,
            dewpointC: typeof latest.dewp === "number" ? latest.dewp : null,
            windDirectionDegrees: typeof latest.wdir === "number" ? latest.wdir : null,
            windSpeedKts: typeof latest.wspd === "number" ? latest.wspd : null,
            rawReport: typeof latest.rawOb === "string" ? latest.rawOb : null,
            stationName: typeof latest.name === "string" ? latest.name : null,
            sourceUrl,
            fetchedAt: new Date().toISOString(),
            stale: false,
            freshness: "fresh",
            cacheHit: false,
        },
        recentTemperatures,
    };
};
export const fetchLatestMetarObservation = async (location) => {
    return (await fetchMetarSnapshot(location)).observation;
};
