import { DEFAULT_LOCATION, LOCATION_REGISTRY } from "../../config.js";
export const resolveLocation = (locationId = DEFAULT_LOCATION) => {
    const location = LOCATION_REGISTRY[locationId];
    if (!location) {
        return LOCATION_REGISTRY[DEFAULT_LOCATION];
    }
    return location;
};
export const defaultLocation = resolveLocation();
