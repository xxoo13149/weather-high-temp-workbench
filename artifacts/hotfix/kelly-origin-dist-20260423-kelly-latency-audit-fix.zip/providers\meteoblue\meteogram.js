import { AppError } from "../../domain/errors.js";
import { parseLocalDateTimeInTimeZone, toIsoInTimeZone } from "../../lib/time.js";
export const WEEK_METEOGRAM_VERSION = "2026-03-29.2";
const TEMPERATURE_SERIES = "Temperature";
const PRECIPITATION_SERIES = "Precipitation";
const SHOWERS_SERIES = "Showers";
const WIND_SPEED_SERIES = "Wind speed";
const WIND_GUST_SERIES = "Wind gust";
const WIND_DIRECTION_SERIES = "Wind direction";
const PICTOGRAM_SERIES = "Pictograms";
const directionBuckets = [
    "N",
    "NNE",
    "NE",
    "ENE",
    "E",
    "ESE",
    "SE",
    "SSE",
    "S",
    "SSW",
    "SW",
    "WSW",
    "W",
    "WNW",
    "NW",
    "NNW",
];
const normalizeUrl = (href) => {
    const decoded = href.trim().replace(/&amp;/g, "&");
    if (decoded.startsWith("//")) {
        return `https:${decoded}`;
    }
    return new URL(decoded, "https://www.meteoblue.com").toString();
};
const assertWeekMeteogramHighchartsUrl = (url) => {
    if (!url.includes("/images/meteogram") || !url.includes("format=highcharts")) {
        throw new AppError(503, "WEEK_METEOGRAM_URL_INVALID", "Resolved link does not look like a week meteogram highcharts export.", {
            retryable: true,
        });
    }
    return url;
};
export const extractWeekMeteogramHighchartsUrl = (html) => {
    const match = html.match(/(?:data-url|data-href|href)=\"([^\"]*images\/meteogram[^\"]*format=highcharts[^\"]*)\"/i);
    if (!match) {
        throw new AppError(503, "WEEK_METEOGRAM_URL_NOT_FOUND", "Could not find a meteoblue week meteogram highcharts link.", {
            retryable: true,
        });
    }
    return assertWeekMeteogramHighchartsUrl(normalizeUrl(match[1]));
};
export const resolveWeekMeteogramTemperatureUnit = (url, fallbackUnit = "C") => {
    try {
        const parsed = new URL(url);
        const rawUnit = (parsed.searchParams.get("temperature_units") ?? "").trim().toUpperCase();
        return rawUnit === "F" || rawUnit === "C" ? rawUnit : fallbackUnit;
    }
    catch {
        return fallbackUnit;
    }
};
const parseMeteogramJson = (raw) => {
    try {
        return JSON.parse(raw.replace(/^\uFEFF/, ""));
    }
    catch (error) {
        throw new AppError(503, "WEEK_METEOGRAM_PARSE_FAILED", `Could not parse meteoblue week meteogram payload: ${String(error)}`, {
            retryable: true,
        });
    }
};
const round = (value, digits) => Number.parseFloat(value.toFixed(digits));
const normalizeTemperatureToC = (value, unit) => unit === "F" ? round(((value - 32) * 5) / 9, 1) : round(value, 1);
const toWallClockValue = (timestamp) => {
    const iso = new Date(timestamp).toISOString();
    return iso.slice(0, 19).replace("T", " ");
};
const pointTimestampToIso = (point, timeZone) => {
    const sourceText = typeof point.name === "string" && point.name.trim() !== "" ? point.name.trim() : typeof point.x === "number" ? toWallClockValue(point.x) : null;
    if (!sourceText) {
        return null;
    }
    const parsed = parseLocalDateTimeInTimeZone(sourceText, timeZone);
    return parsed ? toIsoInTimeZone(parsed, timeZone) : null;
};
const makeSeriesMap = (series, timeZone) => {
    const map = new Map();
    for (const point of series?.data ?? []) {
        const timestamp = pointTimestampToIso(point, timeZone);
        if (!timestamp) {
            continue;
        }
        map.set(timestamp, point);
    }
    return map;
};
const toWindDirection = (degrees) => {
    if (typeof degrees !== "number" || Number.isNaN(degrees)) {
        return null;
    }
    const normalized = ((degrees % 360) + 360) % 360;
    const index = Math.round(normalized / 22.5) % directionBuckets.length;
    return directionBuckets[index] ?? null;
};
const extractMarkerUrl = (symbol) => {
    if (!symbol) {
        return null;
    }
    const match = symbol.match(/^url\((.+)\)$/i);
    return match ? match[1] : null;
};
const parseSourceUpdatedAt = (text, timeZone) => {
    if (!text) {
        return null;
    }
    const match = text.match(/Last update:\s*(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})/i);
    if (!match) {
        return null;
    }
    const parsed = parseLocalDateTimeInTimeZone(`${match[1]} ${match[2]}`, timeZone);
    return parsed ? toIsoInTimeZone(parsed, timeZone) : null;
};
const findSeries = (series, name) => series.find((entry) => entry.name === name);
export const parseWeekMeteogramHighcharts = (raw, timeZone, temperatureUnit = "C") => {
    const root = parseMeteogramJson(raw);
    const seriesList = root.series ?? [];
    const temperatureSeries = findSeries(seriesList, TEMPERATURE_SERIES);
    if (!temperatureSeries || !Array.isArray(temperatureSeries.data) || temperatureSeries.data.length === 0) {
        throw new AppError(503, "WEEK_METEOGRAM_TEMPERATURE_NOT_FOUND", "Could not find hourly temperature data in the week meteogram payload.", {
            retryable: true,
        });
    }
    const precipitationMap = makeSeriesMap(findSeries(seriesList, PRECIPITATION_SERIES), timeZone);
    const showersMap = makeSeriesMap(findSeries(seriesList, SHOWERS_SERIES), timeZone);
    const windSpeedMap = makeSeriesMap(findSeries(seriesList, WIND_SPEED_SERIES), timeZone);
    const windGustMap = makeSeriesMap(findSeries(seriesList, WIND_GUST_SERIES), timeZone);
    const windDirectionMap = makeSeriesMap(findSeries(seriesList, WIND_DIRECTION_SERIES), timeZone);
    const pictogramMap = makeSeriesMap(findSeries(seriesList, PICTOGRAM_SERIES), timeZone);
    const datedPoints = temperatureSeries.data
        .map((point) => ({ point, timestamp: pointTimestampToIso(point, timeZone) }))
        .filter((entry) => entry.timestamp !== null);
    const items = datedPoints.map((entry, index) => {
        const nextTimestamp = datedPoints[index + 1]?.timestamp ?? null;
        const precipitation = (precipitationMap.get(entry.timestamp)?.y ?? 0) + (showersMap.get(entry.timestamp)?.y ?? 0);
        const windSpeed = windSpeedMap.get(entry.timestamp)?.y;
        const windGust = windGustMap.get(entry.timestamp)?.y;
        const pictogram = pictogramMap.get(entry.timestamp);
        return {
            timestamp: entry.timestamp,
            endAt: nextTimestamp,
            summary: null,
            summaryZh: null,
            iconUrl: extractMarkerUrl(pictogram?.marker?.symbol),
            temperatureC: typeof entry.point.y === "number" ? normalizeTemperatureToC(entry.point.y, temperatureUnit) : null,
            feelsLikeC: null,
            windDirection: toWindDirection(windDirectionMap.get(entry.timestamp)?.direction),
            windSpeedKphMin: typeof windSpeed === "number" ? round(windSpeed, 1) : null,
            windSpeedKphMax: typeof windGust === "number"
                ? round(windGust, 1)
                : typeof windSpeed === "number"
                    ? round(windSpeed, 1)
                    : null,
            precipitationMm: round(precipitation, 2),
            precipitationProbabilityPct: null,
        };
    });
    if (items.length === 0) {
        throw new AppError(503, "WEEK_METEOGRAM_EMPTY", "The week meteogram payload did not contain any hourly timestamps.", {
            retryable: true,
        });
    }
    return {
        sourceUpdatedAt: parseSourceUpdatedAt(root.credits?.text, timeZone),
        items,
    };
};
